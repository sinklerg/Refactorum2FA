package ru.refactorum.refactorum2fa.model;

public record TelegramUser(long id, String username, String firstName) {
    public String visibleName() {
        if (username != null && !username.isBlank()) {
            return "@" + username;
        }
        if (firstName != null && !firstName.isBlank()) {
            return firstName;
        }
        return String.valueOf(id);
    }
}
