package ru.refactorum.refactorum2fa;

import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.Dependency;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.command.TwoFaAuthCommand;
import ru.refactorum.refactorum2fa.command.TwoFaCommand;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.integration.AjQueueIntegration;
import ru.refactorum.refactorum2fa.listener.PlayerActivityListener;
import ru.refactorum.refactorum2fa.listener.ServerGateListener;
import ru.refactorum.refactorum2fa.service.AccountStorage;
import ru.refactorum.refactorum2fa.service.PlaytimeTracker;
import ru.refactorum.refactorum2fa.service.TwoFactorService;
import ru.refactorum.refactorum2fa.telegram.TelegramApiClient;
import ru.refactorum.refactorum2fa.telegram.TelegramBotService;
import ru.refactorum.refactorum2fa.util.FreezeMessageCodec;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Plugin(
        id = "refactorum2fa",
        name = "Refactorum2FA",
        version = "1.2.6",
        description = "Telegram 2FA gate between hub auth server and protected Velocity servers",
        authors = {"Refactorum"},
        dependencies = {@Dependency(id = "ajqueue", optional = true)}
)
public final class Refactorum2FAPlugin {
    private final ProxyServer server;
    private final Logger logger;
    private final Path dataDirectory;

    private ConfigManager configManager;
    private AccountStorage accountStorage;
    private PlaytimeTracker playtimeTracker;
    private TwoFactorService twoFactorService;
    private TelegramApiClient telegramApiClient;
    private TelegramBotService telegramBotService;
    private ServerGateListener serverGateListener;
    private AjQueueIntegration ajQueueIntegration;

    @Inject
    public Refactorum2FAPlugin(ProxyServer server, Logger logger, @DataDirectory Path dataDirectory) {
        this.server = server;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        try {
            Files.createDirectories(dataDirectory);
            this.configManager = new ConfigManager(dataDirectory);
            this.configManager.load();

            this.accountStorage = new AccountStorage(
                    dataDirectory.resolve(configManager.config().storage().file()),
                    configManager.config().storage().autosaveAfterChange(),
                    logger
            );
            this.accountStorage.load();

            this.playtimeTracker = new PlaytimeTracker(server, accountStorage);
            this.twoFactorService = new TwoFactorService(this, server, configManager, accountStorage, playtimeTracker, logger);
            this.telegramApiClient = new TelegramApiClient(configManager.config(), logger);
            this.telegramBotService = new TelegramBotService(telegramApiClient, configManager, twoFactorService, logger, this::reloadPlugin);
            this.twoFactorService.setTelegramBotService(telegramBotService);
            this.ajQueueIntegration = new AjQueueIntegration(this, server, configManager, twoFactorService, logger);
            this.serverGateListener = new ServerGateListener(this, server, configManager, twoFactorService, ajQueueIntegration, logger);

            registerPluginChannels();
            registerCommands();
            registerListeners();
            ajQueueIntegration.registerWithRetries();
            telegramBotService.start();

            logger.info("Refactorum2FA enabled. Data folder: {}", dataDirectory.toAbsolutePath());
        } catch (Exception exception) {
            logger.error("Cannot enable Refactorum2FA", exception);
        }
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        shutdownServices();
    }

    public synchronized void reloadPlugin() throws IOException {
        configManager.reload();
        telegramApiClient.updateConfig(configManager.config());
        telegramBotService.restart();
    }

    private void registerPluginChannels() {
        server.getChannelRegistrar().register(MinecraftChannelIdentifier.from(FreezeMessageCodec.CHANNEL));
    }

    private void registerCommands() {
        CommandMeta linkMeta = server.getCommandManager()
                .metaBuilder("2fatg")
                .plugin(this)
                .build();
        server.getCommandManager().register(linkMeta, new TwoFaCommand(configManager, twoFactorService, this::reloadPlugin));

        CommandMeta authMeta = server.getCommandManager()
                .metaBuilder("2fa")
                .aliases("2faverify")
                .plugin(this)
                .build();
        server.getCommandManager().register(authMeta, new TwoFaAuthCommand(configManager, twoFactorService, serverGateListener));
    }

    private void registerListeners() {
        server.getEventManager().register(this, serverGateListener);
        server.getEventManager().register(this, new PlayerActivityListener(this, server, configManager, twoFactorService));
    }

    private void shutdownServices() {
        if (telegramBotService != null) {
            telegramBotService.stop();
        }
        if (telegramApiClient != null) {
            telegramApiClient.shutdown();
        }
        if (playtimeTracker != null) {
            playtimeTracker.flush();
        }
        if (accountStorage != null) {
            try {
                accountStorage.saveToDisk();
            } catch (IOException exception) {
                logger.error("Cannot save Refactorum2FA data on shutdown", exception);
            }
        }
        if (twoFactorService != null) {
            twoFactorService.shutdown();
        }
    }
}
