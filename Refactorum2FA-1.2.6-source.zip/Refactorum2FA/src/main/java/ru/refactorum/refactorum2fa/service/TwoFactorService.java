package ru.refactorum.refactorum2fa.service;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.config.PluginConfig;
import ru.refactorum.refactorum2fa.model.Account;
import ru.refactorum.refactorum2fa.model.AuthDecision;
import ru.refactorum.refactorum2fa.model.PendingAuth;
import ru.refactorum.refactorum2fa.model.PendingLink;
import ru.refactorum.refactorum2fa.model.TelegramUser;
import ru.refactorum.refactorum2fa.telegram.TelegramBotService;
import ru.refactorum.refactorum2fa.util.FreezeMessageCodec;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

public final class TwoFactorService {
    private final Object plugin;
    private final ProxyServer server;
    private final ConfigManager configManager;
    private final AccountStorage storage;
    private final PlaytimeTracker playtimeTracker;
    private final Logger logger;
    private final SecureRandom random = new SecureRandom();
    private final Map<String, PendingLink> pendingLinks = new ConcurrentHashMap<>();
    private final Map<String, PendingAuth> pendingAuths = new ConcurrentHashMap<>();
    private final ConcurrentMap<UUID, String> pendingAuthByPlayer = new ConcurrentHashMap<>();
    private final Set<UUID> authorizedSessions = ConcurrentHashMap.newKeySet();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(new NamedThreadFactory("refactorum2fa-timeouts"));
    private final MinecraftChannelIdentifier freezeChannel = MinecraftChannelIdentifier.from(FreezeMessageCodec.CHANNEL);
    private volatile TelegramBotService telegramBotService;

    public TwoFactorService(Object plugin,
                            ProxyServer server,
                            ConfigManager configManager,
                            AccountStorage storage,
                            PlaytimeTracker playtimeTracker,
                            Logger logger) {
        this.plugin = plugin;
        this.server = server;
        this.configManager = configManager;
        this.storage = storage;
        this.playtimeTracker = playtimeTracker;
        this.logger = logger;
    }

    public void setTelegramBotService(TelegramBotService telegramBotService) {
        this.telegramBotService = telegramBotService;
    }

    public Optional<Account> account(UUID uuid) {
        return storage.find(uuid);
    }

    public PendingLink createLink(Player player) {
        cleanupExpiredLinks();
        PluginConfig.LinkCode settings = configManager.config().auth().linkCode();
        String code = generateCode(settings.length(), settings.alphabet());
        Instant now = Instant.now();
        PendingLink link = new PendingLink(
                code,
                player.getUniqueId(),
                player.getUsername(),
                now,
                now.plusSeconds(settings.expiresSeconds())
        );
        pendingLinks.put(code, link);
        return link;
    }

    public LinkResult linkByCode(String rawCode, TelegramUser telegramUser) {
        cleanupExpiredLinks();
        String code = rawCode.toUpperCase(Locale.ROOT).trim();
        PendingLink link = pendingLinks.remove(code);
        if (link == null || link.expired(Instant.now())) {
            return new LinkResult(LinkStatus.INVALID_CODE, null);
        }

        if (storage.find(link.uuid()).isPresent()) {
            return new LinkResult(LinkStatus.ACCOUNT_ALREADY_LINKED, storage.find(link.uuid()).orElse(null));
        }

        if (!configManager.config().auth().allowSameTelegramForMultipleAccounts()
                && storage.findByTelegramId(telegramUser.id()).isPresent()) {
            return new LinkResult(LinkStatus.TELEGRAM_ALREADY_USED, storage.findByTelegramId(telegramUser.id()).orElse(null));
        }

        Account account = new Account(
                link.uuid(),
                link.playerName(),
                telegramUser.id(),
                telegramUser.username() == null ? "" : telegramUser.username(),
                Instant.now(),
                false,
                null,
                "unknown",
                "unknown",
                0L
        );
        storage.save(account);
        playtimeTracker.startIfOnline(account);
        server.getPlayer(account.uuid()).ifPresent(player -> player.sendMessage(configManager.messages().minecraft("linked-now")));
        return new LinkResult(LinkStatus.LINKED, account);
    }

    public boolean hasAuthorizedSession(UUID uuid) {
        return authorizedSessions.contains(uuid);
    }

    public void authorizeSession(UUID uuid) {
        authorizedSessions.add(uuid);
    }

    public void clearSession(UUID uuid) {
        authorizedSessions.remove(uuid);
        cancelPendingAuth(uuid);
    }

    public void freezePlayer(Player player) {
        sendFreezeMessage(player, FreezeMessageCodec.ACTION_FREEZE, "Сначала подтвердите вход через Telegram 2FA.");
        resendFreezeWhilePending(player.getUniqueId(), 250L);
        resendFreezeWhilePending(player.getUniqueId(), 750L);
        resendFreezeWhilePending(player.getUniqueId(), 1500L);
    }

    public void unfreezePlayer(Player player) {
        sendFreezeMessage(player, FreezeMessageCodec.ACTION_UNFREEZE, "");
    }

    private void resendFreezeWhilePending(UUID uuid, long delayMillis) {
        server.getScheduler().buildTask(plugin, () -> server.getPlayer(uuid).ifPresent(online -> {
            if (hasPendingAuth(uuid)) {
                sendFreezeMessage(online, FreezeMessageCodec.ACTION_FREEZE, "Сначала подтвердите вход через Telegram 2FA.");
            }
        })).delay(Duration.ofMillis(delayMillis)).schedule();
    }

    private void sendFreezeMessage(Player player, String action, String message) {
        player.getCurrentServer().ifPresent(connection -> sendFreezeMessage(connection, player, action, message));
    }

    private void sendFreezeMessage(ServerConnection connection, Player player, String action, String message) {
        try {
            connection.sendPluginMessage(freezeChannel, FreezeMessageCodec.encode(action, player.getUniqueId(), message));
        } catch (RuntimeException exception) {
            logger.debug("Cannot send Refactorum2FA freeze plugin message for {}", player.getUsername(), exception);
        }
    }

    public boolean hasPendingAuth(UUID uuid) {
        String sessionId = pendingAuthByPlayer.get(uuid);
        return sessionId != null && pendingAuths.containsKey(sessionId);
    }

    public CompletableFuture<AuthDecision> requestLogin(Account account,
                                                        String playerName,
                                                        String address,
                                                        String sourceServer,
                                                        String targetServer) {
        TelegramBotService bot = telegramBotService;
        if (bot == null || !bot.isRunning()) {
            CompletableFuture<AuthDecision> future = new CompletableFuture<>();
            future.complete(configManager.config().auth().failClosed() ? AuthDecision.ERROR : AuthDecision.APPROVED);
            return future;
        }

        String existingSessionId = pendingAuthByPlayer.get(account.uuid());
        if (existingSessionId != null) {
            PendingAuth existing = pendingAuths.get(existingSessionId);
            if (existing != null) {
                return existing.future();
            }
            pendingAuthByPlayer.remove(account.uuid(), existingSessionId);
        }

        String sessionId = generateSessionId();
        CompletableFuture<AuthDecision> future = new CompletableFuture<>();
        PendingAuth pending = new PendingAuth(
                sessionId,
                account.uuid(),
                playerName,
                account.telegramId(),
                address,
                sourceServer,
                targetServer,
                Instant.now(),
                future
        );
        pendingAuths.put(sessionId, pending);
        pendingAuthByPlayer.put(account.uuid(), sessionId);

        scheduler.schedule(() -> completeTimeout(sessionId),
                Math.max(1, configManager.config().auth().loginTimeoutSeconds()),
                TimeUnit.SECONDS);

        bot.sendAuthRequest(pending).whenComplete((ignored, throwable) -> {
            if (throwable != null) {
                logger.warn("Cannot send Telegram auth request for {}", account.playerName(), throwable);
                completeInternal(sessionId, account.telegramId(), AuthDecision.ERROR);
            }
        });

        future.whenComplete((decision, throwable) -> {
            pendingAuths.remove(sessionId);
            pendingAuthByPlayer.remove(account.uuid(), sessionId);
        });
        return future;
    }

    public CompleteAuthResult completeAuth(String sessionId, long telegramId, boolean allow) {
        PendingAuth pending = pendingAuths.get(sessionId);
        if (pending == null) {
            return CompleteAuthResult.EXPIRED;
        }
        if (pending.telegramId() != telegramId) {
            return CompleteAuthResult.WRONG_USER;
        }
        boolean completed = completeInternal(sessionId, telegramId, allow ? AuthDecision.APPROVED : AuthDecision.DENIED);
        return completed ? CompleteAuthResult.ACCEPTED : CompleteAuthResult.EXPIRED;
    }

    public void markSuccessfulLogin(Account account, String latestName, String address, String serverName) {
        Account updated = account.withPlayerName(latestName).withLastLogin(Instant.now(), address, serverName);
        storage.save(updated);
    }

    public void unlink(Account account) {
        storage.remove(account.uuid());
        playtimeTracker.forget(account.uuid());
        clearSession(account.uuid());
        server.getPlayer(account.uuid()).ifPresent(player -> player.sendMessage(configManager.messages().minecraft("unlinked-now")));
    }

    public void block(Account account) {
        Account updated = account.withBlocked(true);
        storage.save(updated);
        clearSession(updated.uuid());
        server.getPlayer(updated.uuid()).ifPresent(player -> {
            Component message = configManager.messages().minecraft("blocked-chat");
            player.sendMessage(message);
            if (configManager.config().auth().blockOnlinePlayer().kick()) {
                Duration delay = Duration.ofSeconds(Math.max(0, configManager.config().auth().blockOnlinePlayer().delaySeconds()));
                server.getScheduler().buildTask(plugin, () -> player.disconnect(configManager.messages().minecraft("login-denied-blocked")))
                        .delay(delay)
                        .schedule();
            }
        });
    }

    public void unblock(Account account) {
        storage.save(account.withBlocked(false));
    }

    public boolean kick(Account account, Component reason) {
        Optional<Player> player = server.getPlayer(account.uuid());
        player.ifPresent(value -> value.disconnect(reason));
        return player.isPresent();
    }

    public long playTimeSeconds(Account account) {
        return playtimeTracker.totalSeconds(account);
    }

    public boolean isOnline(Account account) {
        return server.getPlayer(account.uuid()).isPresent();
    }

    public Optional<Account> findByTelegramId(long telegramId) {
        return storage.findByTelegramId(telegramId);
    }

    public Optional<Account> findAny(String identifier) {
        return storage.findByAnyIdentifier(identifier);
    }

    public AccountStorage storage() {
        return storage;
    }

    public PlaytimeTracker playtimeTracker() {
        return playtimeTracker;
    }

    public void shutdown() {
        scheduler.shutdownNow();
    }

    private void cancelPendingAuth(UUID uuid) {
        String sessionId = pendingAuthByPlayer.remove(uuid);
        if (sessionId == null) {
            return;
        }
        PendingAuth pending = pendingAuths.remove(sessionId);
        if (pending != null) {
            pending.future().complete(AuthDecision.DENIED);
        }
    }

    private boolean completeInternal(String sessionId, long telegramId, AuthDecision decision) {
        PendingAuth pending = pendingAuths.get(sessionId);
        if (pending == null || pending.telegramId() != telegramId) {
            return false;
        }
        return pending.future().complete(decision);
    }

    private void completeTimeout(String sessionId) {
        PendingAuth pending = pendingAuths.get(sessionId);
        if (pending != null) {
            pending.future().complete(AuthDecision.TIMEOUT);
        }
    }

    private void cleanupExpiredLinks() {
        Instant now = Instant.now();
        pendingLinks.entrySet().removeIf(entry -> entry.getValue().expired(now));
    }

    private String generateCode(int length, String alphabet) {
        String safeAlphabet = alphabet == null || alphabet.isBlank() ? "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" : alphabet;
        int safeLength = Math.max(4, Math.min(32, length));
        StringBuilder builder = new StringBuilder(safeLength);
        for (int index = 0; index < safeLength; index++) {
            builder.append(safeAlphabet.charAt(random.nextInt(safeAlphabet.length())));
        }
        return builder.toString();
    }

    private String generateSessionId() {
        byte[] bytes = new byte[12];
        random.nextBytes(bytes);
        StringBuilder builder = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            builder.append(String.format("%02x", value));
        }
        return builder.toString();
    }

    public record LinkResult(LinkStatus status, Account account) {
    }

    public enum LinkStatus {
        LINKED,
        INVALID_CODE,
        ACCOUNT_ALREADY_LINKED,
        TELEGRAM_ALREADY_USED
    }

    public enum CompleteAuthResult {
        ACCEPTED,
        EXPIRED,
        WRONG_USER
    }

    private static final class NamedThreadFactory implements ThreadFactory {
        private final String prefix;
        private int counter;

        private NamedThreadFactory(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public synchronized Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, prefix + "-" + counter++);
            thread.setDaemon(true);
            return thread;
        }
    }
}
