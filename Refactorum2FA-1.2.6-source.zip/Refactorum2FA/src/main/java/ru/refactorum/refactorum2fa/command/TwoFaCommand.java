package ru.refactorum.refactorum2fa.command;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.model.PendingLink;
import ru.refactorum.refactorum2fa.service.TwoFactorService;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class TwoFaCommand implements SimpleCommand {
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;
    private final ReloadAction reloadAction;

    public TwoFaCommand(ConfigManager configManager, TwoFactorService twoFactorService, ReloadAction reloadAction) {
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
        this.reloadAction = reloadAction;
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        String[] args = invocation.arguments();

        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            handleReload(source);
            return;
        }

        if (!(source instanceof Player player)) {
            source.sendMessage(configManager.messages().minecraft("player-only"));
            return;
        }

        if (twoFactorService.account(player.getUniqueId()).isPresent()) {
            player.sendMessage(configManager.messages().minecraft("already-linked", Map.of(
                    "bot", configManager.config().telegram().botUsername()
            )));
            return;
        }

        PendingLink link = twoFactorService.createLink(player);
        player.sendMessage(configManager.messages().minecraft("link-generated", Map.of(
                "bot", configManager.config().telegram().botUsername(),
                "code", link.code(),
                "seconds", String.valueOf(configManager.config().auth().linkCode().expiresSeconds())
        )));
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        if (!invocation.source().hasPermission(configManager.config().permissions().reload())) {
            return List.of();
        }
        if (args.length == 0) {
            return List.of("reload");
        }
        if (args.length == 1 && "reload".startsWith(args[0].toLowerCase(Locale.ROOT))) {
            return List.of("reload");
        }
        return List.of();
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return true;
    }

    private void handleReload(CommandSource source) {
        if (!source.hasPermission(configManager.config().permissions().reload())) {
            source.sendMessage(configManager.messages().minecraft("unknown-command"));
            return;
        }
        try {
            reloadAction.reload();
            source.sendMessage(configManager.messages().minecraft("reload-success"));
        } catch (Exception exception) {
            source.sendMessage(configManager.messages().minecraft("unknown-command"));
        }
    }

    @FunctionalInterface
    public interface ReloadAction {
        void reload() throws Exception;
    }
}
