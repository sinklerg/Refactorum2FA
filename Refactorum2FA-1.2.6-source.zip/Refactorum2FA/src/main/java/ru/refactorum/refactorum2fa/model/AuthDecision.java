package ru.refactorum.refactorum2fa.model;

public enum AuthDecision {
    APPROVED,
    DENIED,
    TIMEOUT,
    ERROR
}
