package ru.refactorum.refactorum2fa.telegram;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.config.PluginConfig;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public final class TelegramApiClient {
    private final Gson gson = new Gson();
    private final Logger logger;
    private final ExecutorService executor;
    private volatile PluginConfig config;

    public TelegramApiClient(PluginConfig config, Logger logger) {
        this.config = config;
        this.logger = logger;
        this.executor = Executors.newCachedThreadPool(new NamedThreadFactory("refactorum2fa-telegram-api"));
    }

    public void updateConfig(PluginConfig config) {
        this.config = config;
    }

    public CompletableFuture<JsonObject> callAsync(String method, JsonObject payload) {
        return CompletableFuture.supplyAsync(() -> call(method, payload), executor);
    }

    public JsonObject call(String method, JsonObject payload) {
        PluginConfig snapshot = config;
        if (!snapshot.telegramConfigured()) {
            throw new IllegalStateException("Telegram bot token is not configured");
        }

        HttpURLConnection connection = null;
        try {
            URL url = new URL(snapshot.telegram().api().baseUrl() + "/bot" + snapshot.telegram().botToken() + "/" + method);
            byte[] body = gson.toJson(payload == null ? new JsonObject() : payload).getBytes(StandardCharsets.UTF_8);

            /*
             * Some rented HTTP proxies do not work reliably with Java's
             * HttpURLConnection proxy authentication for HTTPS CONNECT. Curl proves
             * that these proxies are valid, but Java can still fail with HTTP 407.
             * For HTTP proxies with credentials we therefore perform CONNECT
             * manually and send the HTTPS Telegram request through the established
             * tunnel. SOCKS and direct connections continue using HttpURLConnection.
             */
            PluginConfig.Proxy proxyConfig = snapshot.telegram().proxy();
            if (proxyConfig.enabled()
                    && proxyConfig.type() == PluginConfig.ProxyType.HTTP
                    && proxyConfig.hasCredentials()
                    && "https".equalsIgnoreCase(url.getProtocol())) {
                String response = callThroughAuthenticatedHttpProxy(url, body, proxyConfig, snapshot.telegram().api());
                JsonObject json = JsonParser.parseString(response).getAsJsonObject();
                if (!json.has("ok") || !json.get("ok").getAsBoolean()) {
                    throw new IllegalStateException("Telegram API error: " + response);
                }
                return json;
            }

            configureProxyAuthentication(proxyConfig);
            connection = openConnection(url, proxyConfig);
            connection.setConnectTimeout(snapshot.telegram().api().connectTimeoutMs());
            connection.setReadTimeout(snapshot.telegram().api().readTimeoutMs());
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            applyProxyAuthorization(connection, proxyConfig);
            connection.setDoOutput(true);

            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
            }

            int status = connection.getResponseCode();
            String response = readResponse(connection, status);
            JsonObject json = JsonParser.parseString(response).getAsJsonObject();
            if (!json.has("ok") || !json.get("ok").getAsBoolean()) {
                throw new IllegalStateException("Telegram API error: " + response);
            }
            return json;
        } catch (IOException | RuntimeException exception) {
            throw new TelegramApiException("Cannot call Telegram method " + method, exception);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    public JsonArray getUpdates(long offset, int timeoutSeconds) {
        JsonObject payload = new JsonObject();
        payload.addProperty("offset", offset);
        payload.addProperty("timeout", timeoutSeconds);

        JsonArray allowed = new JsonArray();
        allowed.add("message");
        allowed.add("callback_query");
        payload.add("allowed_updates", allowed);

        return call("getUpdates", payload).getAsJsonArray("result");
    }

    public CompletableFuture<Void> sendMessage(long chatId, String text, JsonObject replyMarkup) {
        JsonObject payload = new JsonObject();
        payload.addProperty("chat_id", chatId);
        payload.addProperty("text", text);
        payload.addProperty("disable_web_page_preview", true);
        if (replyMarkup != null) {
            payload.add("reply_markup", replyMarkup);
        }
        return callAsync("sendMessage", payload).thenApply(ignored -> null);
    }

    public CompletableFuture<Void> editMessageText(long chatId, int messageId, String text, JsonObject replyMarkup) {
        JsonObject payload = new JsonObject();
        payload.addProperty("chat_id", chatId);
        payload.addProperty("message_id", messageId);
        payload.addProperty("text", text);
        if (replyMarkup != null) {
            payload.add("reply_markup", replyMarkup);
        }
        return callAsync("editMessageText", payload).thenApply(ignored -> null);
    }

    public CompletableFuture<Void> answerCallback(String callbackId, String text) {
        JsonObject payload = new JsonObject();
        payload.addProperty("callback_query_id", callbackId);
        payload.addProperty("text", text);
        payload.addProperty("show_alert", false);
        return callAsync("answerCallbackQuery", payload).thenApply(ignored -> null);
    }

    public void shutdown() {
        executor.shutdownNow();
    }


    private void configureProxyAuthentication(PluginConfig.Proxy proxyConfig) {
        if (!proxyConfig.enabled() || !proxyConfig.hasCredentials()) {
            return;
        }

        /*
         * Java blocks Basic authentication for HTTPS proxy tunneling by default.
         * Most rented HTTP proxies use Basic auth during CONNECT, so without these
         * properties Telegram requests fail with HTTP 407 even when credentials are
         * correct. The properties are process-wide, but they only relax Java's HTTP
         * client auth filter; actual credentials are still provided by Authenticator.
         */
        if (proxyConfig.type() == PluginConfig.ProxyType.HTTP) {
            System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
            System.setProperty("jdk.http.auth.proxying.disabledSchemes", "");
        }

        Authenticator.setDefault(new TelegramProxyAuthenticator(proxyConfig));
    }

    private HttpURLConnection openConnection(URL url, PluginConfig.Proxy proxyConfig) throws IOException {
        if (!proxyConfig.enabled()) {
            return (HttpURLConnection) url.openConnection();
        }
        Proxy.Type proxyType = proxyConfig.type() == PluginConfig.ProxyType.HTTP ? Proxy.Type.HTTP : Proxy.Type.SOCKS;
        Proxy proxy = new Proxy(proxyType, new InetSocketAddress(proxyConfig.host(), proxyConfig.port()));
        return (HttpURLConnection) url.openConnection(proxy);
    }

    private void applyProxyAuthorization(HttpURLConnection connection, PluginConfig.Proxy proxyConfig) {
        if (!proxyConfig.enabled() || !proxyConfig.hasCredentials() || proxyConfig.type() != PluginConfig.ProxyType.HTTP) {
            return;
        }
        String raw = proxyConfig.username() + ":" + Objects.toString(proxyConfig.password(), "");
        String encoded = Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        connection.setRequestProperty("Proxy-Authorization", "Basic " + encoded);
    }

    private String callThroughAuthenticatedHttpProxy(
            URL url,
            byte[] body,
            PluginConfig.Proxy proxyConfig,
            PluginConfig.TelegramApi apiConfig
    ) throws IOException {
        String targetHost = url.getHost();
        int targetPort = url.getPort() > 0 ? url.getPort() : 443;
        String targetPath = url.getFile() == null || url.getFile().isBlank() ? "/" : url.getFile();

        try (Socket proxySocket = new Socket()) {
            proxySocket.connect(new InetSocketAddress(proxyConfig.host(), proxyConfig.port()), apiConfig.connectTimeoutMs());
            proxySocket.setSoTimeout(apiConfig.readTimeoutMs());

            String rawAuth = proxyConfig.username() + ":" + Objects.toString(proxyConfig.password(), "");
            String encodedAuth = Base64.getEncoder().encodeToString(rawAuth.getBytes(StandardCharsets.UTF_8));
            String connectRequest = "CONNECT " + targetHost + ":" + targetPort + " HTTP/1.1\r\n"
                    + "Host: " + targetHost + ":" + targetPort + "\r\n"
                    + "Proxy-Authorization: Basic " + encodedAuth + "\r\n"
                    + "Proxy-Connection: Keep-Alive\r\n"
                    + "User-Agent: Refactorum2FA\r\n"
                    + "\r\n";
            proxySocket.getOutputStream().write(connectRequest.getBytes(StandardCharsets.ISO_8859_1));
            proxySocket.getOutputStream().flush();

            HttpResponse connectResponse = readHttpResponse(proxySocket.getInputStream(), false);
            if (connectResponse.statusCode() != 200) {
                throw new IOException("Proxy CONNECT failed with HTTP " + connectResponse.statusCode() + ": " + connectResponse.body());
            }

            SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            try (SSLSocket sslSocket = (SSLSocket) sslSocketFactory.createSocket(proxySocket, targetHost, targetPort, true)) {
                sslSocket.setSoTimeout(apiConfig.readTimeoutMs());
                sslSocket.startHandshake();

                String requestHeaders = "POST " + targetPath + " HTTP/1.1\r\n"
                        + "Host: " + targetHost + "\r\n"
                        + "Content-Type: application/json; charset=utf-8\r\n"
                        + "Accept: application/json\r\n"
                        + "User-Agent: Refactorum2FA\r\n"
                        + "Connection: close\r\n"
                        + "Content-Length: " + body.length + "\r\n"
                        + "\r\n";

                OutputStream output = sslSocket.getOutputStream();
                output.write(requestHeaders.getBytes(StandardCharsets.ISO_8859_1));
                output.write(body);
                output.flush();

                HttpResponse telegramResponse = readHttpResponse(sslSocket.getInputStream(), true);
                if (telegramResponse.statusCode() < 200 || telegramResponse.statusCode() >= 300) {
                    throw new IOException("Telegram HTTP status " + telegramResponse.statusCode() + ": " + telegramResponse.body());
                }
                return telegramResponse.body();
            }
        }
    }

    private HttpResponse readHttpResponse(InputStream rawInput, boolean readBody) throws IOException {
        BufferedInputStream input = rawInput instanceof BufferedInputStream
                ? (BufferedInputStream) rawInput
                : new BufferedInputStream(rawInput);

        String headerBlock = readHeaderBlock(input);
        String[] lines = headerBlock.split("\\r?\\n");
        if (lines.length == 0 || !lines[0].startsWith("HTTP/")) {
            throw new IOException("Invalid HTTP response from proxy/Telegram");
        }

        String[] statusParts = lines[0].split(" ", 3);
        int statusCode = statusParts.length >= 2 ? Integer.parseInt(statusParts[1]) : -1;
        Map<String, String> headers = new HashMap<>();
        for (int i = 1; i < lines.length; i++) {
            int separator = lines[i].indexOf(':');
            if (separator <= 0) {
                continue;
            }
            headers.put(lines[i].substring(0, separator).trim().toLowerCase(Locale.ROOT), lines[i].substring(separator + 1).trim());
        }

        if (!readBody) {
            return new HttpResponse(statusCode, headers, "");
        }

        byte[] bodyBytes;
        String transferEncoding = headers.getOrDefault("transfer-encoding", "");
        if (transferEncoding.toLowerCase(Locale.ROOT).contains("chunked")) {
            bodyBytes = readChunkedBody(input);
        } else if (headers.containsKey("content-length")) {
            int contentLength = Integer.parseInt(headers.get("content-length"));
            bodyBytes = input.readNBytes(contentLength);
        } else {
            bodyBytes = input.readAllBytes();
        }

        return new HttpResponse(statusCode, headers, new String(bodyBytes, StandardCharsets.UTF_8));
    }

    private String readHeaderBlock(BufferedInputStream input) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int matched = 0;
        int value;
        byte[] delimiter = new byte[] {'\r', '\n', '\r', '\n'};
        while ((value = input.read()) != -1) {
            buffer.write(value);
            if (value == delimiter[matched]) {
                matched++;
                if (matched == delimiter.length) {
                    break;
                }
            } else {
                matched = value == delimiter[0] ? 1 : 0;
            }
        }
        return buffer.toString(StandardCharsets.ISO_8859_1);
    }

    private byte[] readChunkedBody(BufferedInputStream input) throws IOException {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        while (true) {
            String sizeLine = readLine(input);
            int semicolon = sizeLine.indexOf(';');
            String sizeText = semicolon >= 0 ? sizeLine.substring(0, semicolon) : sizeLine;
            int size = Integer.parseInt(sizeText.trim(), 16);
            if (size == 0) {
                readLine(input);
                break;
            }
            body.write(input.readNBytes(size));
            readLine(input);
        }
        return body.toByteArray();
    }

    private String readLine(BufferedInputStream input) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int previous = -1;
        int current;
        while ((current = input.read()) != -1) {
            if (previous == '\r' && current == '\n') {
                byte[] bytes = buffer.toByteArray();
                return new String(bytes, 0, Math.max(0, bytes.length - 1), StandardCharsets.ISO_8859_1);
            }
            buffer.write(current);
            previous = current;
        }
        return buffer.toString(StandardCharsets.ISO_8859_1);
    }


    private String readResponse(HttpURLConnection connection, int status) throws IOException {
        InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) {
            return "{}";
        }
        try (InputStream input = stream) {
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }


    private static final class TelegramProxyAuthenticator extends Authenticator {
        private final String host;
        private final int port;
        private final String username;
        private final char[] password;

        private TelegramProxyAuthenticator(PluginConfig.Proxy proxyConfig) {
            this.host = proxyConfig.host();
            this.port = proxyConfig.port();
            this.username = proxyConfig.username();
            this.password = Objects.toString(proxyConfig.password(), "").toCharArray();
        }

        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            if (getRequestorType() != RequestorType.PROXY) {
                return null;
            }
            if (getRequestingPort() != port) {
                return null;
            }
            String requestingHost = getRequestingHost();
            if (requestingHost != null && !requestingHost.equalsIgnoreCase(host)) {
                return null;
            }
            return new PasswordAuthentication(username, password);
        }
    }

    private record HttpResponse(int statusCode, Map<String, String> headers, String body) {
    }

    public static final class TelegramApiException extends RuntimeException {
        public TelegramApiException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static final class NamedThreadFactory implements ThreadFactory {
        private final String prefix;
        private int counter;

        private NamedThreadFactory(String prefix) {
            this.prefix = prefix;
        }

        @Override
        public synchronized Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, prefix + "-" + counter++);
            thread.setDaemon(true);
            return thread;
        }
    }
}
