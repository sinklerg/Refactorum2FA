package ru.refactorum.refactorum2fa.integration;

import com.velocitypowered.api.plugin.PluginContainer;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.service.TwoFactorService;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AjQueueIntegration {
    private static final String API_CLASS = "us.ajg0702.queue.api.AjQueueAPI";
    private static final String PRE_QUEUE_EVENT_CLASS = "us.ajg0702.queue.api.events.PreQueueEvent";
    private static final String AUTO_QUEUE_ON_KICK_EVENT_CLASS = "us.ajg0702.queue.api.events.AutoQueueOnKickEvent";
    private static final String EVENT_RECEIVER_CLASS = "us.ajg0702.queue.api.events.utils.EventReceiver";

    private final Object plugin;
    private final ProxyServer server;
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;
    private final Logger logger;
    private final AtomicBoolean preQueueRegistered = new AtomicBoolean(false);
    private final AtomicBoolean autoQueueRegistered = new AtomicBoolean(false);

    public AjQueueIntegration(Object plugin,
                              ProxyServer server,
                              ConfigManager configManager,
                              TwoFactorService twoFactorService,
                              Logger logger) {
        this.plugin = plugin;
        this.server = server;
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
        this.logger = logger;
    }

    public void registerWithRetries() {
        tryRegister(false);
        server.getScheduler().buildTask(plugin, () -> tryRegister(false)).delay(Duration.ofSeconds(2)).schedule();
        server.getScheduler().buildTask(plugin, () -> tryRegister(true)).delay(Duration.ofSeconds(10)).schedule();
    }

    private void tryRegister(boolean finalAttempt) {
        if (preQueueRegistered.get() && autoQueueRegistered.get()) {
            return;
        }
        if (!configManager.config().auth().blockQueueCommandsUntil2fa()) {
            return;
        }

        for (ClassLoader classLoader : resolveClassLoaders()) {
            try {
                Object api = apiInstance(classLoader);
                if (api == null) {
                    continue;
                }

                if (!preQueueRegistered.get()) {
                    registerEventListener(
                            classLoader,
                            api,
                            PRE_QUEUE_EVENT_CLASS,
                            event -> handleQueueLikeEvent(event, "getPlayer")
                    );
                    preQueueRegistered.set(true);
                    logger.info("Refactorum2FA hooked into ajQueue PreQueueEvent. Linked players cannot enter queues before Telegram 2FA.");
                }

                if (!autoQueueRegistered.get()) {
                    registerEventListener(
                            classLoader,
                            api,
                            AUTO_QUEUE_ON_KICK_EVENT_CLASS,
                            event -> handleQueueLikeEvent(event, "getPlayer")
                    );
                    autoQueueRegistered.set(true);
                    logger.info("Refactorum2FA hooked into ajQueue AutoQueueOnKickEvent. Pending 2FA players cannot be auto-queued.");
                }
                return;
            } catch (ClassNotFoundException ignored) {
                // Try the next classloader. Velocity can isolate plugin classes.
            } catch (ReflectiveOperationException | RuntimeException exception) {
                logger.warn("Cannot hook ajQueue API with classloader {}. Refactorum2FA will still block configured queue commands.", classLoader, exception);
            }
        }

        if (finalAttempt && !preQueueRegistered.get()) {
            logger.info("ajQueue API is not available to Refactorum2FA. Command/NPC interaction blocking remains active, but direct ajQueue API calls cannot be intercepted.");
        }
    }

    private void registerEventListener(ClassLoader classLoader,
                                       Object api,
                                       String eventClassName,
                                       ThrowingConsumer<Object> consumer) throws ReflectiveOperationException, ClassNotFoundException {
        Class<?> apiClass = Class.forName(API_CLASS, false, classLoader);
        Class<?> eventClass = Class.forName(eventClassName, false, classLoader);
        Class<?> receiverClass = Class.forName(EVENT_RECEIVER_CLASS, false, classLoader);

        Object receiver = java.lang.reflect.Proxy.newProxyInstance(
                receiverClass.getClassLoader(),
                new Class<?>[]{receiverClass},
                (proxy, method, args) -> {
                    if ("execute".equals(method.getName()) && args != null && args.length == 1) {
                        try {
                            consumer.accept(args[0]);
                        } catch (ReflectiveOperationException | ClassCastException exception) {
                            logger.debug("Cannot process ajQueue event {}", eventClassName, exception);
                        }
                    }
                    return null;
                }
        );

        Method listen = apiClass.getMethod("listen", Class.class, receiverClass);
        listen.invoke(api, eventClass, receiver);
    }

    public void removePlayerQueues(Player player) {
        if (!configManager.config().auth().blockQueueCommandsUntil2fa()) {
            return;
        }

        for (ClassLoader classLoader : resolveClassLoaders()) {
            try {
                Object api = apiInstance(classLoader);
                if (api == null) {
                    continue;
                }

                Object platformMethods = invoke(api, "getPlatformMethods");
                Object adaptedPlayer = invokeCompatible(platformMethods, "getPlayer", player.getUniqueId());
                if (adaptedPlayer == null) {
                    adaptedPlayer = invokeCompatible(platformMethods, "getPlayer", player.getUsername());
                }
                if (adaptedPlayer == null) {
                    continue;
                }

                Object queueManager = invoke(api, "getQueueManager");
                invokeCompatible(queueManager, "clear", adaptedPlayer);
                logger.debug("Cleared ajQueue queues for {} before Telegram 2FA approval.", player.getUsername());
                return;
            } catch (ClassNotFoundException ignored) {
                // ajQueue is not installed or not visible through this classloader.
            } catch (ReflectiveOperationException | ClassCastException exception) {
                logger.debug("Cannot clear ajQueue queues for {}", player.getUsername(), exception);
            }
        }
    }

    private Object apiInstance(ClassLoader classLoader) throws ReflectiveOperationException, ClassNotFoundException {
        Class<?> apiClass = Class.forName(API_CLASS, false, classLoader);
        return apiClass.getMethod("getInstance").invoke(null);
    }

    private void handleQueueLikeEvent(Object event, String playerGetter) throws ReflectiveOperationException {
        Object adaptedPlayer = invoke(event, playerGetter);
        UUID uuid = (UUID) invoke(adaptedPlayer, "getUniqueId");

        if (!shouldBlockQueue(uuid)) {
            return;
        }

        invoke(event, "setCancelled", boolean.class, true);
        Optional<Player> online = server.getPlayer(uuid);
        online.ifPresent(player -> {
            twoFactorService.freezePlayer(player);
            removePlayerQueues(player);
            player.sendMessage(configManager.messages().minecraft("queue-command-blocked-pending"));
        });
    }

    private boolean shouldBlockQueue(UUID uuid) {
        if (!configManager.config().auth().blockQueueCommandsUntil2fa()) {
            return false;
        }
        if (twoFactorService.hasAuthorizedSession(uuid)) {
            return false;
        }
        return twoFactorService.account(uuid).isPresent();
    }

    private List<ClassLoader> resolveClassLoaders() {
        Set<ClassLoader> classLoaders = new LinkedHashSet<>();
        addClassLoader(classLoaders, Thread.currentThread().getContextClassLoader());
        addClassLoader(classLoaders, getClass().getClassLoader());
        server.getPluginManager().getPlugin("ajqueue")
                .flatMap(PluginContainer::getInstance)
                .map(instance -> instance.getClass().getClassLoader())
                .ifPresent(classLoader -> addClassLoader(classLoaders, classLoader));
        server.getPluginManager().getPlugin("ajQueue")
                .flatMap(PluginContainer::getInstance)
                .map(instance -> instance.getClass().getClassLoader())
                .ifPresent(classLoader -> addClassLoader(classLoaders, classLoader));
        server.getPluginManager().getPlugin("ajqueueplus")
                .flatMap(PluginContainer::getInstance)
                .map(instance -> instance.getClass().getClassLoader())
                .ifPresent(classLoader -> addClassLoader(classLoaders, classLoader));
        return new ArrayList<>(classLoaders);
    }

    private void addClassLoader(Set<ClassLoader> classLoaders, ClassLoader classLoader) {
        if (classLoader != null) {
            classLoaders.add(classLoader);
        }
    }

    private Object invokeCompatible(Object target, String methodName, Object value) throws ReflectiveOperationException {
        if (target == null) {
            return null;
        }
        for (Method method : target.getClass().getMethods()) {
            if (!methodName.equals(method.getName()) || method.getParameterCount() != 1) {
                continue;
            }
            if (value != null && !wrap(method.getParameterTypes()[0]).isInstance(value)) {
                continue;
            }
            try {
                return method.invoke(target, value);
            } catch (InvocationTargetException exception) {
                throw new ReflectiveOperationException(exception.getCause());
            }
        }
        return null;
    }

    private Object invoke(Object target, String methodName) throws ReflectiveOperationException {
        try {
            return target.getClass().getMethod(methodName).invoke(target);
        } catch (InvocationTargetException exception) {
            throw new ReflectiveOperationException(exception.getCause());
        }
    }

    private Object invoke(Object target, String methodName, Class<?> parameterType, Object value) throws ReflectiveOperationException {
        try {
            return target.getClass().getMethod(methodName, parameterType).invoke(target, value);
        } catch (InvocationTargetException exception) {
            throw new ReflectiveOperationException(exception.getCause());
        }
    }

    private Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) {
            return type;
        }
        if (type == boolean.class) {
            return Boolean.class;
        }
        if (type == int.class) {
            return Integer.class;
        }
        if (type == long.class) {
            return Long.class;
        }
        if (type == double.class) {
            return Double.class;
        }
        if (type == float.class) {
            return Float.class;
        }
        if (type == short.class) {
            return Short.class;
        }
        if (type == byte.class) {
            return Byte.class;
        }
        if (type == char.class) {
            return Character.class;
        }
        return type;
    }

    @FunctionalInterface
    private interface ThrowingConsumer<T> {
        void accept(T value) throws ReflectiveOperationException;
    }
}
