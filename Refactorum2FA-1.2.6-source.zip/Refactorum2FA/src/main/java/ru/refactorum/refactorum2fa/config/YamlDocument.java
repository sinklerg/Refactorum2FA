package ru.refactorum.refactorum2fa.config;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class YamlDocument {
    private final Path path;
    private final String resourceName;
    private Map<String, Object> root = new LinkedHashMap<>();
    private Map<String, Object> defaults = new LinkedHashMap<>();

    public YamlDocument(Path path, String resourceName) {
        this.path = path;
        this.resourceName = resourceName;
    }

    public void load() throws IOException {
        loadDefaults();
        copyDefaultIfMissing();

        Yaml yaml = new Yaml();
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            Object loaded = yaml.load(reader);
            if (loaded instanceof Map<?, ?> map) {
                this.root = normalizeMap(map);
            } else {
                this.root = new LinkedHashMap<>();
            }
        }
    }

    public void save(Map<String, Object> data) throws IOException {
        Files.createDirectories(path.getParent());

        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        options.setIndent(2);

        Yaml yaml = new Yaml(options);
        try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            yaml.dump(data, writer);
        }
        this.root = new LinkedHashMap<>(data);
    }

    public Path path() {
        return path;
    }

    public Map<String, Object> root() {
        return root;
    }

    public String getString(String path, String def) {
        return find(path)
                .map(Object::toString)
                .orElse(def);
    }

    public int getInt(String path, int def) {
        return find(path)
                .map(value -> parseNumber(value, def).intValue())
                .orElse(def);
    }

    public long getLong(String path, long def) {
        return find(path)
                .map(value -> parseNumber(value, def).longValue())
                .orElse(def);
    }

    public boolean getBoolean(String path, boolean def) {
        return find(path)
                .map(value -> {
                    if (value instanceof Boolean b) {
                        return b;
                    }
                    return Boolean.parseBoolean(value.toString());
                })
                .orElse(def);
    }

    public List<String> getStringList(String path) {
        Optional<Object> value = find(path);
        if (value.isEmpty() || !(value.get() instanceof Iterable<?> iterable)) {
            return List.of();
        }

        List<String> result = new ArrayList<>();
        for (Object entry : iterable) {
            if (entry != null && !entry.toString().isBlank()) {
                result.add(entry.toString());
            }
        }
        return List.copyOf(result);
    }

    public List<Long> getLongList(String path) {
        Optional<Object> value = find(path);
        if (value.isEmpty() || !(value.get() instanceof Iterable<?> iterable)) {
            return List.of();
        }

        List<Long> result = new ArrayList<>();
        for (Object entry : iterable) {
            try {
                result.add(Long.parseLong(entry.toString()));
            } catch (NumberFormatException ignored) {
                // Incorrect Telegram IDs in config are ignored instead of breaking plugin startup.
            }
        }
        return List.copyOf(result);
    }

    public Optional<Object> find(String path) {
        Optional<Object> configured = findIn(root, path);
        return configured.isPresent() ? configured : findIn(defaults, path);
    }

    private Optional<Object> findIn(Map<String, Object> source, String path) {
        String[] parts = path.split("\\.");
        Object current = source;
        for (String part : parts) {
            if (!(current instanceof Map<?, ?> map)) {
                return Optional.empty();
            }
            current = map.get(part);
            if (current == null) {
                return Optional.empty();
            }
        }
        return Optional.of(current);
    }

    private Number parseNumber(Object value, long def) {
        if (value instanceof Number number) {
            return number;
        }
        try {
            return Long.parseLong(value.toString());
        } catch (NumberFormatException ignored) {
            return def;
        }
    }

    private void loadDefaults() throws IOException {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(resourceName)) {
            if (input == null) {
                defaults = new LinkedHashMap<>();
                return;
            }
            Yaml yaml = new Yaml();
            Object loaded = yaml.load(input);
            if (loaded instanceof Map<?, ?> map) {
                defaults = normalizeMap(map);
            } else {
                defaults = new LinkedHashMap<>();
            }
        }
    }

    private void copyDefaultIfMissing() throws IOException {
        if (Files.exists(path)) {
            return;
        }
        Files.createDirectories(path.getParent());
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(resourceName)) {
            if (input == null) {
                Files.createFile(path);
                return;
            }
            Files.copy(input, path);
        }
    }

    private Map<String, Object> normalizeMap(Map<?, ?> map) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            String key = String.valueOf(entry.getKey());
            Object value = entry.getValue();
            if (value instanceof Map<?, ?> child) {
                normalized.put(key, normalizeMap(child));
            } else if (value instanceof List<?> list) {
                normalized.put(key, normalizeList(list));
            } else {
                normalized.put(key, value);
            }
        }
        return normalized;
    }

    private List<Object> normalizeList(List<?> list) {
        List<Object> normalized = new ArrayList<>();
        for (Object value : list) {
            if (value instanceof Map<?, ?> child) {
                normalized.add(normalizeMap(child));
            } else if (value instanceof List<?> childList) {
                normalized.add(normalizeList(childList));
            } else {
                normalized.add(value);
            }
        }
        return normalized;
    }
}
