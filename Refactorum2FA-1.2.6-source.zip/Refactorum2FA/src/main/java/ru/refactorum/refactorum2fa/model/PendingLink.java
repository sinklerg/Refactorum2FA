package ru.refactorum.refactorum2fa.model;

import java.time.Instant;
import java.util.UUID;

public record PendingLink(
        String code,
        UUID uuid,
        String playerName,
        Instant createdAt,
        Instant expiresAt
) {
    public boolean expired(Instant now) {
        return now.isAfter(expiresAt);
    }
}
