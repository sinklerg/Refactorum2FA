package ru.refactorum.refactorum2fa.telegram;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.model.Account;
import ru.refactorum.refactorum2fa.model.PendingAuth;
import ru.refactorum.refactorum2fa.model.TelegramUser;
import ru.refactorum.refactorum2fa.service.TwoFactorService;
import ru.refactorum.refactorum2fa.util.FormatUtil;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class TelegramBotService {
    private static final int TECH_PAGE_SIZE = 7;

    private final TelegramApiClient apiClient;
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;
    private final Logger logger;
    private final ReloadAction reloadAction;

    private volatile boolean running;
    private volatile Thread pollingThread;
    private long offset;

    public TelegramBotService(TelegramApiClient apiClient,
                              ConfigManager configManager,
                              TwoFactorService twoFactorService,
                              Logger logger,
                              ReloadAction reloadAction) {
        this.apiClient = apiClient;
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
        this.logger = logger;
        this.reloadAction = reloadAction;
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        if (!configManager.config().telegramConfigured()) {
            logger.warn("Telegram bot token is not configured. Linked players will be handled by auth.fail-closed policy.");
            return;
        }

        running = true;
        pollingThread = new Thread(this::pollingLoop, "refactorum2fa-telegram-polling");
        pollingThread.setDaemon(true);
        pollingThread.start();
        logger.info("Telegram bot polling started for @{}", configManager.config().telegram().botUsername());
    }

    public synchronized void stop() {
        running = false;
        Thread thread = pollingThread;
        if (thread != null) {
            thread.interrupt();
        }
    }

    public synchronized void restart() {
        stop();
        start();
    }

    public boolean isRunning() {
        return running;
    }

    public CompletableFuture<Void> sendAuthRequest(PendingAuth pending) {
        Map<String, String> placeholders = new HashMap<>();
        placeholders.put("player", pending.playerName());
        placeholders.put("ip", safeValue(pending.address()));
        placeholders.put("source_server", safeValue(pending.sourceServer()));
        placeholders.put("target_server", safeValue(pending.targetServer()));
        placeholders.put("time", formatInstant(pending.requestedAt()));

        return apiClient.sendMessage(pending.telegramId(), t("auth-request", placeholders), authKeyboard(pending.sessionId()));
    }

    private void pollingLoop() {
        while (running) {
            try {
                JsonArray updates = apiClient.getUpdates(offset, configManager.config().telegram().api().pollingTimeoutSeconds());
                for (JsonElement element : updates) {
                    JsonObject update = element.getAsJsonObject();
                    if (update.has("update_id")) {
                        offset = update.get("update_id").getAsLong() + 1;
                    }
                    handleUpdate(update);
                }
            } catch (RuntimeException exception) {
                if (running) {
                    logger.warn("Telegram polling error", exception);
                    sleep(configManager.config().telegram().api().retryDelayMs());
                }
            }
        }
        logger.info("Telegram bot polling stopped");
    }

    private void handleUpdate(JsonObject update) {
        if (update.has("message")) {
            handleMessage(update.getAsJsonObject("message"));
        }
        if (update.has("callback_query")) {
            handleCallback(update.getAsJsonObject("callback_query"));
        }
    }

    private void handleMessage(JsonObject message) {
        if (!message.has("text") || !message.has("chat") || !message.has("from")) {
            return;
        }

        long chatId = message.getAsJsonObject("chat").get("id").getAsLong();
        TelegramUser user = readUser(message.getAsJsonObject("from"));
        String text = message.get("text").getAsString().trim();
        String command = commandName(text);

        if (command.equals("/tech")) {
            handleTech(chatId, user, text);
            return;
        }

        if (command.equals("/start")) {
            send(chatId, t("start"), null);
            twoFactorService.findByTelegramId(user.id()).ifPresent(account -> sendMainMenu(chatId, account));
            return;
        }

        if (command.equals("/link")) {
            handleLink(chatId, user, text);
            return;
        }

        if (isStatus(text, command)) {
            handleOwnStatus(chatId, user);
            return;
        }
        if (isUnlink(text, command)) {
            handleOwnUnlink(chatId, user);
            return;
        }
        if (isKick(text, command)) {
            handleOwnKick(chatId, user);
            return;
        }
        if (isBlock(text, command)) {
            handleOwnBlock(chatId, user);
            return;
        }
        if (isUnblock(text, command)) {
            handleOwnUnblock(chatId, user);
            return;
        }

        send(chatId, t("unknown-command"), null);
    }

    private void handleLink(long chatId, TelegramUser user, String text) {
        String[] parts = text.split("\\s+", 2);
        if (parts.length < 2 || parts[1].isBlank()) {
            send(chatId, t("link-usage"), null);
            return;
        }

        TwoFactorService.LinkResult result = twoFactorService.linkByCode(parts[1], user);
        switch (result.status()) {
            case LINKED -> {
                Account account = result.account();
                send(chatId, t("linked", Map.of("player", account.playerName())), mainMenuKeyboard());
                send(chatId, t("linked-help"), mainMenuKeyboard());
            }
            case INVALID_CODE -> send(chatId, t("code-invalid"), null);
            case ACCOUNT_ALREADY_LINKED -> send(chatId, t("code-already-linked"), null);
            case TELEGRAM_ALREADY_USED -> send(chatId, t("telegram-already-used"), null);
        }
    }

    private void handleOwnStatus(long chatId, TelegramUser user) {
        Optional<Account> account = twoFactorService.findByTelegramId(user.id());
        if (account.isEmpty()) {
            send(chatId, t("not-linked"), null);
            return;
        }
        sendStatus(chatId, account.get(), mainMenuKeyboard());
    }

    private void handleOwnUnlink(long chatId, TelegramUser user) {
        Optional<Account> account = twoFactorService.findByTelegramId(user.id());
        if (account.isEmpty()) {
            send(chatId, t("not-linked"), null);
            return;
        }
        twoFactorService.unlink(account.get());
        send(chatId, t("unlinked", Map.of("player", account.get().playerName())), null);
    }

    private void handleOwnKick(long chatId, TelegramUser user) {
        Optional<Account> account = twoFactorService.findByTelegramId(user.id());
        if (account.isEmpty()) {
            send(chatId, t("not-linked"), null);
            return;
        }
        boolean kicked = twoFactorService.kick(account.get(), configManager.messages().minecraft("login-denied-rejected"));
        send(chatId, t(kicked ? "kicked" : "kick-offline", Map.of("player", account.get().playerName())), mainMenuKeyboard());
    }

    private void handleOwnBlock(long chatId, TelegramUser user) {
        Optional<Account> account = twoFactorService.findByTelegramId(user.id());
        if (account.isEmpty()) {
            send(chatId, t("not-linked"), null);
            return;
        }
        twoFactorService.block(account.get());
        send(chatId, t("blocked", Map.of("player", account.get().playerName())), mainMenuKeyboard());
    }

    private void handleOwnUnblock(long chatId, TelegramUser user) {
        Optional<Account> account = twoFactorService.findByTelegramId(user.id());
        if (account.isEmpty()) {
            send(chatId, t("not-linked"), null);
            return;
        }
        send(chatId, t("unblock-denied", Map.of("player", account.get().playerName())), mainMenuKeyboard());
    }

    private void handleCallback(JsonObject callback) {
        if (!callback.has("data") || !callback.has("from") || !callback.has("id")) {
            return;
        }
        String data = callback.get("data").getAsString();
        TelegramUser user = readUser(callback.getAsJsonObject("from"));

        if (data.startsWith("auth:")) {
            handleAuthCallback(callback, user, data);
            return;
        }
        if (data.startsWith("tech:")) {
            handleTechCallback(callback, user, data);
            return;
        }

        answer(callback.get("id").getAsString(), t("unknown-command"));
    }

    private void handleAuthCallback(JsonObject callback, TelegramUser user, String data) {
        String callbackId = callback.get("id").getAsString();
        String[] parts = data.split(":", 3);
        if (parts.length != 3) {
            answer(callbackId, t("unknown-command"));
            return;
        }

        boolean allow = parts[1].equalsIgnoreCase("allow");
        TwoFactorService.CompleteAuthResult result = twoFactorService.completeAuth(parts[2], user.id(), allow);
        if (result == TwoFactorService.CompleteAuthResult.ACCEPTED) {
            String key = allow ? "auth-approved" : "auth-denied";
            String player = twoFactorService.findByTelegramId(user.id()).map(Account::playerName).orElse(t("auth-fallback-player"));
            String text = t(key, Map.of("player", player));
            answer(callbackId, text);
            editCallbackMessage(callback, text, null);
            callbackChatId(callback).ifPresent(chatId -> send(chatId, t("menu", Map.of("player", player)), mainMenuKeyboard()));
            return;
        }

        if (result == TwoFactorService.CompleteAuthResult.EXPIRED) {
            answer(callbackId, t("auth-expired"));
        } else {
            answer(callbackId, t("unknown-command"));
        }
    }

    private void handleTech(long chatId, TelegramUser user, String text) {
        if (!isTechAdmin(user.id())) {
            send(chatId, t("unknown-command"), null);
            return;
        }

        String[] args = text.split("\\s+");
        if (args.length == 1) {
            send(chatId, t("tech-dashboard"), techDashboardKeyboard());
            return;
        }

        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> handleTechList(chatId, args);
            case "info", "status" -> handleTechInfo(chatId, args);
            case "unlink", "delete", "remove" -> handleTechUnlink(chatId, args);
            case "block" -> handleTechBlock(chatId, args);
            case "unblock" -> handleTechUnblock(chatId, args);
            case "kick" -> handleTechKick(chatId, args);
            case "reload" -> handleTechReload(chatId);
            default -> send(chatId, t("tech-dashboard"), techDashboardKeyboard());
        }
    }

    private void handleTechCallback(JsonObject callback, TelegramUser user, String data) {
        String callbackId = callback.get("id").getAsString();
        if (!isTechAdmin(user.id())) {
            answer(callbackId, t("unknown-command"));
            return;
        }

        String[] parts = data.split(":", 3);
        String action = parts.length >= 2 ? parts[1].toLowerCase(Locale.ROOT) : "menu";
        String value = parts.length >= 3 ? parts[2] : "";

        switch (action) {
            case "menu" -> {
                answer(callbackId, t("tech-callback-opened"));
                editCallbackMessage(callback, t("tech-dashboard"), techDashboardKeyboard());
            }
            case "list" -> {
                int page = parsePage(value, techPages());
                answer(callbackId, t("tech-callback-opened"));
                editCallbackMessage(callback, techListText(page), techListKeyboard(page));
            }
            case "account", "refresh" -> editTechAccount(callback, callbackId, value, "tech-callback-opened");
            case "block" -> mutateTechAccount(callback, callbackId, value, TechAction.BLOCK);
            case "unblock" -> mutateTechAccount(callback, callbackId, value, TechAction.UNBLOCK);
            case "kick" -> mutateTechAccount(callback, callbackId, value, TechAction.KICK);
            case "unlink" -> mutateTechAccount(callback, callbackId, value, TechAction.UNLINK);
            case "reload" -> handleTechReloadCallback(callback, callbackId);
            default -> {
                answer(callbackId, t("unknown-command"));
                editCallbackMessage(callback, t("tech-dashboard"), techDashboardKeyboard());
            }
        }
    }

    private void handleTechList(long chatId, String[] args) {
        int page = args.length >= 3 ? parsePage(args[2], techPages()) : 1;
        send(chatId, techListText(page), techListKeyboard(page));
    }

    private String techListText(int page) {
        List<Account> accounts = twoFactorService.storage().all();
        if (accounts.isEmpty()) {
            return t("tech-no-accounts");
        }

        int pages = techPages(accounts);
        int safePage = Math.max(1, Math.min(page, pages));
        int start = (safePage - 1) * TECH_PAGE_SIZE;
        int end = Math.min(accounts.size(), start + TECH_PAGE_SIZE);

        StringBuilder builder = new StringBuilder(t("tech-list-header", Map.of(
                "page", String.valueOf(safePage),
                "pages", String.valueOf(pages),
                "count", String.valueOf(accounts.size())
        )));
        for (int index = start; index < end; index++) {
            Account account = accounts.get(index);
            builder.append('\n').append(t("tech-list-line", techPlaceholders(account, Map.of(
                    "index", String.valueOf(index + 1)
            ))));
        }
        return builder.toString();
    }

    private JsonObject techListKeyboard(int page) {
        List<Account> accounts = twoFactorService.storage().all();
        if (accounts.isEmpty()) {
            return techDashboardKeyboard();
        }

        int pages = techPages(accounts);
        int safePage = Math.max(1, Math.min(page, pages));
        int start = (safePage - 1) * TECH_PAGE_SIZE;
        int end = Math.min(accounts.size(), start + TECH_PAGE_SIZE);

        JsonArray rows = new JsonArray();
        for (int index = start; index < end; index++) {
            Account account = accounts.get(index);
            rows.add(inlineRow(inlineButton(accountButtonText(account), "tech:account:" + account.uuid())));
        }

        JsonArray navigation = new JsonArray();
        if (safePage > 1) {
            navigation.add(inlineButton(t("buttons.tech.previous"), "tech:list:" + (safePage - 1)));
        }
        navigation.add(inlineButton(t("buttons.tech.dashboard"), "tech:menu"));
        if (safePage < pages) {
            navigation.add(inlineButton(t("buttons.tech.next"), "tech:list:" + (safePage + 1)));
        }
        rows.add(navigation);
        return inlineKeyboard(rows);
    }

    private void handleTechInfo(long chatId, String[] args) {
        Optional<Account> account = techFind(args);
        if (account.isEmpty()) {
            send(chatId, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        send(chatId, techInfoText(account.get()), techAccountKeyboard(account.get()));
    }

    private void handleTechUnlink(long chatId, String[] args) {
        Optional<Account> account = techFind(args);
        if (account.isEmpty()) {
            send(chatId, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        twoFactorService.unlink(account.get());
        send(chatId, t("tech-action-unlinked", Map.of("player", account.get().playerName())), techDashboardKeyboard());
    }

    private void handleTechBlock(long chatId, String[] args) {
        Optional<Account> account = techFind(args);
        if (account.isEmpty()) {
            send(chatId, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        twoFactorService.block(account.get());
        Account updated = twoFactorService.account(account.get().uuid()).orElse(account.get().withBlocked(true));
        send(chatId, techInfoText(updated), techAccountKeyboard(updated));
    }

    private void handleTechUnblock(long chatId, String[] args) {
        Optional<Account> account = techFind(args);
        if (account.isEmpty()) {
            send(chatId, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        twoFactorService.unblock(account.get());
        Account updated = twoFactorService.account(account.get().uuid()).orElse(account.get().withBlocked(false));
        send(chatId, techInfoText(updated), techAccountKeyboard(updated));
    }

    private void handleTechKick(long chatId, String[] args) {
        Optional<Account> account = techFind(args);
        if (account.isEmpty()) {
            send(chatId, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        boolean kicked = twoFactorService.kick(account.get(), configManager.messages().minecraft("login-denied-rejected"));
        send(chatId, t(kicked ? "tech-action-kicked" : "tech-action-kick-offline", Map.of("player", account.get().playerName())), techAccountKeyboard(account.get()));
    }

    private void handleTechReload(long chatId) {
        try {
            reloadAction.reload();
            send(chatId, t("tech-reload-success"), techDashboardKeyboard());
        } catch (Exception exception) {
            logger.warn("Cannot reload Refactorum2FA from Telegram", exception);
            send(chatId, t("tech-reload-error", Map.of("error", exception.getMessage() == null ? "unknown" : exception.getMessage())), techDashboardKeyboard());
        }
    }

    private void handleTechReloadCallback(JsonObject callback, String callbackId) {
        try {
            reloadAction.reload();
            answer(callbackId, t("tech-reload-success-short"));
            editCallbackMessage(callback, t("tech-dashboard"), techDashboardKeyboard());
        } catch (Exception exception) {
            logger.warn("Cannot reload Refactorum2FA from Telegram", exception);
            answer(callbackId, t("tech-reload-error-short"));
            editCallbackMessage(callback, t("tech-reload-error", Map.of("error", exception.getMessage() == null ? "unknown" : exception.getMessage())), techDashboardKeyboard());
        }
    }

    private void editTechAccount(JsonObject callback, String callbackId, String identifier, String answerKey) {
        Optional<Account> account = findAccount(identifier);
        if (account.isEmpty()) {
            answer(callbackId, t("tech-account-not-found-short"));
            editCallbackMessage(callback, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }
        answer(callbackId, t(answerKey));
        editCallbackMessage(callback, techInfoText(account.get()), techAccountKeyboard(account.get()));
    }

    private void mutateTechAccount(JsonObject callback, String callbackId, String identifier, TechAction action) {
        Optional<Account> optionalAccount = findAccount(identifier);
        if (optionalAccount.isEmpty()) {
            answer(callbackId, t("tech-account-not-found-short"));
            editCallbackMessage(callback, t("tech-account-not-found"), techDashboardKeyboard());
            return;
        }

        Account account = optionalAccount.get();
        switch (action) {
            case BLOCK -> {
                twoFactorService.block(account);
                Account updated = twoFactorService.account(account.uuid()).orElse(account.withBlocked(true));
                answer(callbackId, t("tech-action-blocked-short"));
                editCallbackMessage(callback, techInfoText(updated), techAccountKeyboard(updated));
            }
            case UNBLOCK -> {
                twoFactorService.unblock(account);
                Account updated = twoFactorService.account(account.uuid()).orElse(account.withBlocked(false));
                answer(callbackId, t("tech-action-unblocked-short"));
                editCallbackMessage(callback, techInfoText(updated), techAccountKeyboard(updated));
            }
            case KICK -> {
                boolean kicked = twoFactorService.kick(account, configManager.messages().minecraft("login-denied-rejected"));
                answer(callbackId, t(kicked ? "tech-action-kicked-short" : "tech-action-kick-offline-short"));
                editCallbackMessage(callback, techInfoText(account), techAccountKeyboard(account));
            }
            case UNLINK -> {
                twoFactorService.unlink(account);
                answer(callbackId, t("tech-action-unlinked-short"));
                editCallbackMessage(callback, t("tech-action-unlinked", Map.of("player", account.playerName())), techDashboardKeyboard());
            }
        }
    }

    private Optional<Account> techFind(String[] args) {
        if (args.length < 3) {
            return Optional.empty();
        }
        return findAccount(args[2]);
    }

    private Optional<Account> findAccount(String identifier) {
        if (identifier == null || identifier.isBlank()) {
            return Optional.empty();
        }
        try {
            UUID uuid = UUID.fromString(identifier);
            return twoFactorService.account(uuid);
        } catch (IllegalArgumentException ignored) {
            return twoFactorService.findAny(identifier);
        }
    }

    private void sendStatus(long chatId, Account account, JsonObject keyboard) {
        send(chatId, statusText(account), keyboard);
    }

    private String statusText(Account account) {
        return t("status", accountPlaceholders(account));
    }

    private String techInfoText(Account account) {
        return t("tech-info", techPlaceholders(account, Map.of()));
    }

    private Map<String, String> accountPlaceholders(Account account) {
        Map<String, String> placeholders = new HashMap<>();
        placeholders.put("player", account.playerName());
        placeholders.put("uuid", account.uuid().toString());
        placeholders.put("telegram_id", String.valueOf(account.telegramId()));
        placeholders.put("telegram_username", account.telegramUsername() == null || account.telegramUsername().isBlank() ? t("format.empty") : "@" + account.telegramUsername());
        placeholders.put("linked_at", formatInstant(account.linkedAt()));
        placeholders.put("online", formatOnline(twoFactorService.isOnline(account)));
        placeholders.put("playtime", formatDuration(twoFactorService.playTimeSeconds(account)));
        placeholders.put("last_login", formatInstant(account.lastLoginAt()));
        placeholders.put("last_ip", safeValue(account.lastLoginAddress()));
        placeholders.put("last_server", safeValue(account.lastLoginServer()));
        placeholders.put("blocked", formatYesNo(account.blocked()));
        placeholders.put("blocked_icon", account.blocked() ? t("icons.blocked") : t("icons.unblocked"));
        placeholders.put("online_icon", twoFactorService.isOnline(account) ? t("icons.online") : t("icons.offline"));
        return placeholders;
    }

    private Map<String, String> techPlaceholders(Account account, Map<String, String> additional) {
        Map<String, String> placeholders = new HashMap<>(accountPlaceholders(account));
        placeholders.putAll(additional);
        return placeholders;
    }

    private String formatInstant(Instant instant) {
        return FormatUtil.instant(instant, t("format.never"));
    }

    private String formatDuration(long seconds) {
        return FormatUtil.duration(
                seconds,
                t("format.duration-days"),
                t("format.duration-hours"),
                t("format.duration-minutes")
        );
    }

    private String formatYesNo(boolean value) {
        return FormatUtil.yesNo(value, t("format.yes"), t("format.no"));
    }

    private String formatOnline(boolean value) {
        return FormatUtil.online(value, t("format.online"), t("format.offline"));
    }

    private String safeValue(String value) {
        if (value == null || value.isBlank() || value.equalsIgnoreCase("unknown")) {
            return t("format.unknown");
        }
        return value;
    }

    private void sendMainMenu(long chatId, Account account) {
        send(chatId, t("menu", Map.of("player", account.playerName())), mainMenuKeyboard());
    }

    private void send(long chatId, String text, JsonObject keyboard) {
        apiClient.sendMessage(chatId, text, keyboard).exceptionally(throwable -> {
            logger.warn("Cannot send Telegram message to {}", chatId, throwable);
            return null;
        });
    }

    private void answer(String callbackId, String text) {
        apiClient.answerCallback(callbackId, text).exceptionally(throwable -> {
            logger.warn("Cannot answer Telegram callback", throwable);
            return null;
        });
    }

    private void editCallbackMessage(JsonObject callback, String text, JsonObject keyboard) {
        if (!callback.has("message")) {
            return;
        }
        JsonObject message = callback.getAsJsonObject("message");
        long chatId = message.getAsJsonObject("chat").get("id").getAsLong();
        int messageId = message.get("message_id").getAsInt();
        apiClient.editMessageText(chatId, messageId, text, keyboard).exceptionally(throwable -> {
            logger.warn("Cannot edit Telegram message", throwable);
            return null;
        });
    }

    private Optional<Long> callbackChatId(JsonObject callback) {
        if (!callback.has("message")) {
            return Optional.empty();
        }
        JsonObject message = callback.getAsJsonObject("message");
        if (!message.has("chat")) {
            return Optional.empty();
        }
        return Optional.of(message.getAsJsonObject("chat").get("id").getAsLong());
    }

    private TelegramUser readUser(JsonObject from) {
        long id = from.get("id").getAsLong();
        String username = from.has("username") ? from.get("username").getAsString() : "";
        String firstName = from.has("first_name") ? from.get("first_name").getAsString() : "";
        return new TelegramUser(id, username, firstName);
    }

    private String commandName(String text) {
        String first = text.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int mentionIndex = first.indexOf('@');
        if (mentionIndex >= 0) {
            return first.substring(0, mentionIndex);
        }
        return first;
    }

    private boolean isTechAdmin(long telegramId) {
        return configManager.config().telegram().techAdminIds().contains(telegramId);
    }

    private int techPages() {
        return techPages(twoFactorService.storage().all());
    }

    private int techPages(List<Account> accounts) {
        return Math.max(1, (int) Math.ceil(accounts.size() / (double) TECH_PAGE_SIZE));
    }

    private int parsePage(String value, int max) {
        try {
            return Math.max(1, Math.min(max, Integer.parseInt(value)));
        } catch (NumberFormatException ignored) {
            return 1;
        }
    }

    private boolean isStatus(String text, String command) {
        return command.equals("/status") || matchesButton(text, "status");
    }

    private boolean isUnlink(String text, String command) {
        return command.equals("/unlink") || matchesButton(text, "unlink");
    }

    private boolean isKick(String text, String command) {
        return command.equals("/kick") || matchesButton(text, "kick");
    }

    private boolean isBlock(String text, String command) {
        return command.equals("/block") || matchesButton(text, "block");
    }

    private boolean isUnblock(String text, String command) {
        return command.equals("/unblock") || matchesButton(text, "unblock");
    }

    private boolean matchesButton(String text, String key) {
        String configured = t("buttons.user." + key);
        String alias = t("buttons.user-aliases." + key);
        return text.equalsIgnoreCase(configured) || (!alias.isBlank() && text.equalsIgnoreCase(alias));
    }

    private String accountButtonText(Account account) {
        return t("buttons.tech.account", accountPlaceholders(account));
    }

    private JsonObject mainMenuKeyboard() {
        return replyKeyboard(new String[][]{
                {t("buttons.user.status")},
                {t("buttons.user.kick"), t("buttons.user.block")},
                {t("buttons.user.unlink")}
        });
    }

    private JsonObject techDashboardKeyboard() {
        JsonArray rows = new JsonArray();
        rows.add(inlineRow(
                inlineButton(t("buttons.tech.list"), "tech:list:1"),
                inlineButton(t("buttons.tech.reload"), "tech:reload")
        ));
        return inlineKeyboard(rows);
    }

    private JsonObject techAccountKeyboard(Account account) {
        JsonArray rows = new JsonArray();
        rows.add(inlineRow(inlineButton(t("buttons.tech.refresh"), "tech:refresh:" + account.uuid())));
        if (account.blocked()) {
            rows.add(inlineRow(inlineButton(t("buttons.tech.unblock"), "tech:unblock:" + account.uuid())));
        } else {
            rows.add(inlineRow(inlineButton(t("buttons.tech.block"), "tech:block:" + account.uuid())));
        }
        rows.add(inlineRow(
                inlineButton(t("buttons.tech.kick"), "tech:kick:" + account.uuid()),
                inlineButton(t("buttons.tech.unlink"), "tech:unlink:" + account.uuid())
        ));
        rows.add(inlineRow(
                inlineButton(t("buttons.tech.back-to-list"), "tech:list:1"),
                inlineButton(t("buttons.tech.dashboard"), "tech:menu")
        ));
        return inlineKeyboard(rows);
    }

    private JsonObject replyKeyboard(String[][] rows) {
        JsonObject markup = new JsonObject();
        JsonArray keyboard = new JsonArray();
        for (String[] row : rows) {
            JsonArray rowArray = new JsonArray();
            for (String button : row) {
                JsonObject buttonObject = new JsonObject();
                buttonObject.addProperty("text", button);
                rowArray.add(buttonObject);
            }
            keyboard.add(rowArray);
        }
        markup.add("keyboard", keyboard);
        markup.addProperty("resize_keyboard", true);
        markup.addProperty("one_time_keyboard", false);
        return markup;
    }

    private JsonObject authKeyboard(String sessionId) {
        JsonArray rows = new JsonArray();
        rows.add(inlineRow(
                inlineButton(t("buttons.auth.allow"), "auth:allow:" + sessionId),
                inlineButton(t("buttons.auth.deny"), "auth:deny:" + sessionId)
        ));
        return inlineKeyboard(rows);
    }

    private JsonObject inlineKeyboard(JsonArray rows) {
        JsonObject markup = new JsonObject();
        markup.add("inline_keyboard", rows);
        return markup;
    }

    private JsonArray inlineRow(JsonObject... buttons) {
        JsonArray row = new JsonArray();
        for (JsonObject button : buttons) {
            row.add(button);
        }
        return row;
    }

    private JsonObject inlineButton(String text, String callbackData) {
        JsonObject button = new JsonObject();
        button.addProperty("text", text);
        button.addProperty("callback_data", callbackData);
        return button;
    }

    private String t(String key) {
        return configManager.messages().telegram(key);
    }

    private String t(String key, Map<String, String> placeholders) {
        return configManager.messages().telegram(key, placeholders);
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(Math.max(100, millis));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
    }

    private enum TechAction {
        BLOCK,
        UNBLOCK,
        KICK,
        UNLINK
    }

    @FunctionalInterface
    public interface ReloadAction {
        void reload() throws Exception;
    }
}
