package ru.refactorum.refactorum2fa.model;

import java.time.Instant;
import java.util.UUID;

public record Account(
        UUID uuid,
        String playerName,
        long telegramId,
        String telegramUsername,
        Instant linkedAt,
        boolean blocked,
        Instant lastLoginAt,
        String lastLoginAddress,
        String lastLoginServer,
        long playTimeSeconds
) {
    public Account withPlayerName(String newName) {
        return new Account(uuid, newName, telegramId, telegramUsername, linkedAt, blocked, lastLoginAt, lastLoginAddress, lastLoginServer, playTimeSeconds);
    }

    public Account withTelegram(long newTelegramId, String newTelegramUsername) {
        return new Account(uuid, playerName, newTelegramId, newTelegramUsername, linkedAt, blocked, lastLoginAt, lastLoginAddress, lastLoginServer, playTimeSeconds);
    }

    public Account withBlocked(boolean newBlocked) {
        return new Account(uuid, playerName, telegramId, telegramUsername, linkedAt, newBlocked, lastLoginAt, lastLoginAddress, lastLoginServer, playTimeSeconds);
    }

    public Account withLastLogin(Instant loginAt, String address, String serverName) {
        return new Account(uuid, playerName, telegramId, telegramUsername, linkedAt, blocked, loginAt, address, serverName, playTimeSeconds);
    }

    public Account withPlayTimeSeconds(long seconds) {
        return new Account(uuid, playerName, telegramId, telegramUsername, linkedAt, blocked, lastLoginAt, lastLoginAddress, lastLoginServer, Math.max(0, seconds));
    }
}
