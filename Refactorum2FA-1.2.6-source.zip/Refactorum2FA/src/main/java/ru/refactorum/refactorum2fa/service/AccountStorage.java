package ru.refactorum.refactorum2fa.service;

import org.slf4j.Logger;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;
import ru.refactorum.refactorum2fa.model.Account;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AccountStorage {
    private final Path path;
    private final boolean autosave;
    private final Logger logger;
    private final Map<UUID, Account> accounts = new ConcurrentHashMap<>();

    public AccountStorage(Path path, boolean autosave, Logger logger) {
        this.path = path;
        this.autosave = autosave;
        this.logger = logger;
    }

    public synchronized void load() throws IOException {
        Files.createDirectories(path.getParent());
        if (!Files.exists(path)) {
            saveToDisk();
            return;
        }

        accounts.clear();
        Yaml yaml = new Yaml();
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            Object loaded = yaml.load(reader);
            if (!(loaded instanceof Map<?, ?> root)) {
                return;
            }
            Object rawAccounts = root.get("accounts");
            if (!(rawAccounts instanceof Map<?, ?> map)) {
                return;
            }
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                try {
                    UUID uuid = UUID.fromString(String.valueOf(entry.getKey()));
                    if (!(entry.getValue() instanceof Map<?, ?> data)) {
                        continue;
                    }
                    Account account = readAccount(uuid, data);
                    accounts.put(uuid, account);
                } catch (RuntimeException exception) {
                    logger.warn("Cannot load 2FA account {} from data.yml", entry.getKey(), exception);
                }
            }
        }
    }

    public Optional<Account> find(UUID uuid) {
        return Optional.ofNullable(accounts.get(uuid));
    }

    public Optional<Account> findByTelegramId(long telegramId) {
        return accounts.values().stream()
                .filter(account -> account.telegramId() == telegramId)
                .findFirst();
    }

    public Optional<Account> findByPlayerName(String name) {
        String normalized = name.toLowerCase(Locale.ROOT);
        return accounts.values().stream()
                .filter(account -> account.playerName().toLowerCase(Locale.ROOT).equals(normalized))
                .findFirst();
    }

    public Optional<Account> findByAnyIdentifier(String identifier) {
        try {
            return find(UUID.fromString(identifier));
        } catch (IllegalArgumentException ignored) {
            // Not a UUID, continue.
        }

        try {
            long telegramId = Long.parseLong(identifier);
            Optional<Account> account = findByTelegramId(telegramId);
            if (account.isPresent()) {
                return account;
            }
        } catch (NumberFormatException ignored) {
            // Not a Telegram ID, continue.
        }

        return findByPlayerName(identifier);
    }

    public List<Account> all() {
        return accounts.values().stream()
                .sorted(Comparator.comparing(Account::playerName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    public synchronized void save(Account account) {
        accounts.put(account.uuid(), account);
        autosave();
    }

    public synchronized void remove(UUID uuid) {
        accounts.remove(uuid);
        autosave();
    }

    public synchronized void saveToDisk() throws IOException {
        Files.createDirectories(path.getParent());
        Map<String, Object> root = new LinkedHashMap<>();
        Map<String, Object> serializedAccounts = new LinkedHashMap<>();
        for (Account account : all()) {
            serializedAccounts.put(account.uuid().toString(), writeAccount(account));
        }
        root.put("accounts", serializedAccounts);

        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        options.setIndent(2);
        Yaml yaml = new Yaml(options);
        try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            yaml.dump(root, writer);
        }
    }

    private void autosave() {
        if (!autosave) {
            return;
        }
        try {
            saveToDisk();
        } catch (IOException exception) {
            logger.error("Cannot save 2FA data file", exception);
        }
    }

    private Account readAccount(UUID uuid, Map<?, ?> data) {
        return new Account(
                uuid,
                string(data, "player-name", "Unknown"),
                longValue(data, "telegram-id", 0L),
                string(data, "telegram-username", ""),
                instant(data, "linked-at"),
                booleanValue(data, "blocked", false),
                instant(data, "last-login-at"),
                string(data, "last-login-address", "unknown"),
                string(data, "last-login-server", "unknown"),
                longValue(data, "play-time-seconds", 0L)
        );
    }

    private Map<String, Object> writeAccount(Account account) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("player-name", account.playerName());
        data.put("telegram-id", account.telegramId());
        data.put("telegram-username", account.telegramUsername());
        data.put("linked-at", account.linkedAt() == null ? null : account.linkedAt().toString());
        data.put("blocked", account.blocked());
        data.put("last-login-at", account.lastLoginAt() == null ? null : account.lastLoginAt().toString());
        data.put("last-login-address", account.lastLoginAddress());
        data.put("last-login-server", account.lastLoginServer());
        data.put("play-time-seconds", account.playTimeSeconds());
        return data;
    }

    private String string(Map<?, ?> map, String key, String def) {
        Object value = map.get(key);
        return value == null ? def : value.toString();
    }

    private long longValue(Map<?, ?> map, String key, long def) {
        Object value = map.get(key);
        if (value instanceof Number number) {
            return number.longValue();
        }
        if (value == null) {
            return def;
        }
        try {
            return Long.parseLong(value.toString());
        } catch (NumberFormatException ignored) {
            return def;
        }
    }

    private boolean booleanValue(Map<?, ?> map, String key, boolean def) {
        Object value = map.get(key);
        if (value instanceof Boolean bool) {
            return bool;
        }
        return value == null ? def : Boolean.parseBoolean(value.toString());
    }

    private Instant instant(Map<?, ?> map, String key) {
        Object value = map.get(key);
        if (value == null || value.toString().isBlank()) {
            return null;
        }
        return Instant.parse(value.toString());
    }
}
