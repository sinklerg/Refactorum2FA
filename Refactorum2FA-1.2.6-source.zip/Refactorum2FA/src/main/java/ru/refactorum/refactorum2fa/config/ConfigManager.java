package ru.refactorum.refactorum2fa.config;

import java.io.IOException;
import java.nio.file.Path;

public final class ConfigManager {
    private final YamlDocument configDocument;
    private final YamlDocument messagesDocument;
    private PluginConfig config;
    private Messages messages;

    public ConfigManager(Path dataDirectory) {
        this.configDocument = new YamlDocument(dataDirectory.resolve("config.yml"), "config.yml");
        this.messagesDocument = new YamlDocument(dataDirectory.resolve("messages.yml"), "messages.yml");
    }

    public void load() throws IOException {
        configDocument.load();
        messagesDocument.load();
        this.config = PluginConfig.from(configDocument);
        this.messages = new Messages(messagesDocument);
    }

    public void reload() throws IOException {
        load();
    }

    public PluginConfig config() {
        return config;
    }

    public Messages messages() {
        return messages;
    }
}
