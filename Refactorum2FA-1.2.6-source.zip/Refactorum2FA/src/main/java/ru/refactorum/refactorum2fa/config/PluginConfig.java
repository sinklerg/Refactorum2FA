package ru.refactorum.refactorum2fa.config;

import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public record PluginConfig(
        Telegram telegram,
        Network network,
        Auth auth,
        JoinSuggestion joinSuggestion,
        Storage storage,
        Permissions permissions
) {
    public static PluginConfig from(YamlDocument yaml) {
        List<String> protectedServers = defaultIfEmpty(yaml.getStringList("network.protected-servers"), List.of("towny"));
        List<String> suggestionServers = defaultIfEmpty(yaml.getStringList("join-suggestion.servers"), protectedServers);
        List<String> allowedPendingCommands = defaultIfEmpty(
                yaml.getStringList("auth.allowed-commands-while-pending"),
                List.of("login", "l", "register", "reg", "2fa", "2fatg")
        );
        List<String> queueCommands = defaultIfEmpty(
                yaml.getStringList("auth.queue-commands"),
                List.of("queue", "joinqueue", "joinq", "move", "server", "ajqueue", "ajq")
        );

        return new PluginConfig(
                new Telegram(
                        yaml.getString("telegram.bot-token", ""),
                        yaml.getString("telegram.bot-username", "RefactorumBot"),
                        yaml.getLongList("telegram.tech-admin-ids"),
                        new TelegramApi(
                                yaml.getString("telegram.api.base-url", "https://api.telegram.org"),
                                yaml.getInt("telegram.api.connect-timeout-ms", 10000),
                                yaml.getInt("telegram.api.read-timeout-ms", 35000),
                                yaml.getInt("telegram.api.polling-timeout-seconds", 25),
                                yaml.getInt("telegram.api.retry-delay-ms", 3000)
                        ),
                        new Proxy(
                                yaml.getBoolean("telegram.proxy.enabled", false),
                                ProxyType.from(yaml.getString("telegram.proxy.type", "SOCKS")),
                                yaml.getString("telegram.proxy.host", "127.0.0.1"),
                                yaml.getInt("telegram.proxy.port", 1080),
                                yaml.getString("telegram.proxy.username", ""),
                                yaml.getString("telegram.proxy.password", "")
                        )
                ),
                new Network(
                        yaml.getString("network.auth-server", "hub"),
                        yaml.getString("network.target-server", "towny"),
                        protectedServers,
                        yaml.getBoolean("network.gate-only-from-auth-server", true),
                        yaml.getBoolean("network.redirect-initial-protected-to-auth-server", true),
                        yaml.getBoolean("network.auto-connect-after-approval", true)
                ),
                new Auth(
                        yaml.getInt("auth.login-timeout-seconds", 45),
                        yaml.getBoolean("auth.allow-permission-bypass", false),
                        yaml.getBoolean("auth.fail-closed", true),
                        new LinkCode(
                                yaml.getInt("auth.link-code.length", 6),
                                yaml.getInt("auth.link-code.expires-seconds", 300),
                                yaml.getString("auth.link-code.alphabet", "ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
                        ),
                        yaml.getBoolean("auth.allow-same-telegram-for-multiple-accounts", false),
                        new BlockOnlinePlayer(
                                yaml.getBoolean("auth.block-online-player.kick", true),
                                yaml.getInt("auth.block-online-player.delay-seconds", 2)
                        ),
                        yaml.getBoolean("auth.start-2fa-after-login-command", true),
                        defaultIfEmpty(yaml.getStringList("auth.login-commands"), List.of("login", "l")),
                        yaml.getInt("auth.login-command-delay-millis", 0),
                        yaml.getBoolean("auth.block-commands-while-pending", true),
                        yaml.getBoolean("auth.block-all-commands-while-pending", true),
                        allowedPendingCommands,
                        yaml.getBoolean("auth.block-queue-commands-until-2fa", true),
                        queueCommands
                ),
                new JoinSuggestion(
                        yaml.getBoolean("join-suggestion.enabled", true),
                        yaml.getInt("join-suggestion.delay-seconds", 3),
                        yaml.getBoolean("join-suggestion.show-only-unlinked", true),
                        suggestionServers
                ),
                new Storage(
                        yaml.getString("storage.file", "data.yml"),
                        yaml.getBoolean("storage.autosave-after-change", true)
                ),
                new Permissions(
                        yaml.getString("permissions.reload", "refactorum2fa.reload"),
                        yaml.getString("permissions.bypass", "refactorum2fa.bypass")
                )
        );
    }

    public boolean telegramConfigured() {
        String token = telegram.botToken();
        return token != null && !token.isBlank() && !token.equalsIgnoreCase("PUT_TELEGRAM_BOT_TOKEN_HERE");
    }

    private static List<String> defaultIfEmpty(List<String> list, List<String> fallback) {
        return list == null || list.isEmpty() ? fallback : list;
    }

    public record Telegram(
            String botToken,
            String botUsername,
            List<Long> techAdminIds,
            TelegramApi api,
            Proxy proxy
    ) {
    }

    public record TelegramApi(
            String baseUrl,
            int connectTimeoutMs,
            int readTimeoutMs,
            int pollingTimeoutSeconds,
            int retryDelayMs
    ) {
    }

    public record Proxy(
            boolean enabled,
            ProxyType type,
            String host,
            int port,
            String username,
            String password
    ) {
        public boolean hasCredentials() {
            return username != null && !username.isBlank();
        }
    }

    public enum ProxyType {
        HTTP,
        SOCKS;

        public static ProxyType from(String value) {
            try {
                return ProxyType.valueOf(value.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException exception) {
                return SOCKS;
            }
        }
    }

    public record Network(
            String authServer,
            String targetServer,
            List<String> protectedServers,
            boolean gateOnlyFromAuthServer,
            boolean redirectInitialProtectedToAuthServer,
            boolean autoConnectAfterApproval
    ) {
        public boolean isAuthServer(String serverName) {
            return equalsServer(authServer, serverName);
        }

        public boolean isProtectedServer(String serverName) {
            return normalizedProtectedServers().contains(normalize(serverName));
        }

        public Set<String> normalizedProtectedServers() {
            return protectedServers.stream()
                    .map(Network::normalize)
                    .collect(Collectors.toUnmodifiableSet());
        }

        private static boolean equalsServer(String first, String second) {
            return normalize(first).equals(normalize(second));
        }

        private static String normalize(String value) {
            return value == null ? "" : value.toLowerCase(Locale.ROOT).trim();
        }
    }

    public record Auth(
            int loginTimeoutSeconds,
            boolean allowPermissionBypass,
            boolean failClosed,
            LinkCode linkCode,
            boolean allowSameTelegramForMultipleAccounts,
            BlockOnlinePlayer blockOnlinePlayer,
            boolean startTwoFactorAfterLoginCommand,
            List<String> loginCommands,
            int loginCommandDelayMillis,
            boolean blockCommandsWhilePending,
            boolean blockAllCommandsWhilePending,
            List<String> allowedCommandsWhilePending,
            boolean blockQueueCommandsUntil2fa,
            List<String> queueCommands
    ) {
        public boolean isCommandAllowedWhilePending(String commandLine) {
            String label = commandLabel(commandLine);
            if (label.isBlank()) {
                return false;
            }
            return allowedCommandsWhilePending.stream()
                    .map(Auth::normalizeCommandLabel)
                    .anyMatch(label::equals);
        }

        public boolean isLoginCommand(String commandLine) {
            String label = commandLabel(commandLine);
            if (label.isBlank()) {
                return false;
            }
            return loginCommands.stream()
                    .map(Auth::normalizeCommandLabel)
                    .anyMatch(label::equals);
        }

        public boolean isQueueCommand(String commandLine) {
            String label = commandLabel(commandLine);
            if (label.isBlank()) {
                return false;
            }
            return queueCommands.stream()
                    .map(Auth::normalizeCommandLabel)
                    .anyMatch(label::equals);
        }

        public static String commandLabel(String commandLine) {
            if (commandLine == null || commandLine.isBlank()) {
                return "";
            }
            return normalizeCommandLabel(commandLine.trim().split("\\s+", 2)[0]);
        }

        private static String normalizeCommandLabel(String value) {
            if (value == null) {
                return "";
            }
            String normalized = value.toLowerCase(Locale.ROOT).trim();
            while (normalized.startsWith("/")) {
                normalized = normalized.substring(1);
            }
            return normalized;
        }
    }

    public record LinkCode(int length, int expiresSeconds, String alphabet) {
    }

    public record BlockOnlinePlayer(boolean kick, int delaySeconds) {
    }

    public record JoinSuggestion(boolean enabled, int delaySeconds, boolean showOnlyUnlinked, List<String> servers) {
        public boolean appliesTo(String serverName) {
            if (servers == null || servers.isEmpty()) {
                return true;
            }
            String normalized = serverName == null ? "" : serverName.toLowerCase(Locale.ROOT).trim();
            return servers.stream()
                    .map(value -> value.toLowerCase(Locale.ROOT).trim())
                    .anyMatch(normalized::equals);
        }
    }

    public record Storage(String file, boolean autosaveAfterChange) {
    }

    public record Permissions(String reload, String bypass) {
    }
}
