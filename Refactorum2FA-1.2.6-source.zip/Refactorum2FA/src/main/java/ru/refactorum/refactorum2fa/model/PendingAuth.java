package ru.refactorum.refactorum2fa.model;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public record PendingAuth(
        String sessionId,
        UUID uuid,
        String playerName,
        long telegramId,
        String address,
        String sourceServer,
        String targetServer,
        Instant requestedAt,
        CompletableFuture<AuthDecision> future
) {
}
