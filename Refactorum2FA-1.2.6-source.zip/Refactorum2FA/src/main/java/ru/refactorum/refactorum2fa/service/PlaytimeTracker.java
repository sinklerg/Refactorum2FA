package ru.refactorum.refactorum2fa.service;

import com.velocitypowered.api.proxy.ProxyServer;
import ru.refactorum.refactorum2fa.model.Account;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlaytimeTracker {
    private final ProxyServer server;
    private final AccountStorage storage;
    private final Map<UUID, Instant> onlineSince = new ConcurrentHashMap<>();

    public PlaytimeTracker(ProxyServer server, AccountStorage storage) {
        this.server = server;
        this.storage = storage;
    }

    public void start(UUID uuid) {
        onlineSince.putIfAbsent(uuid, Instant.now());
    }

    public void startIfOnline(Account account) {
        if (server.getPlayer(account.uuid()).isPresent()) {
            start(account.uuid());
        }
    }

    public void stopAndSave(UUID uuid) {
        Instant start = onlineSince.remove(uuid);
        if (start == null) {
            return;
        }
        storage.find(uuid).ifPresent(account -> {
            long delta = Math.max(0, Duration.between(start, Instant.now()).getSeconds());
            storage.save(account.withPlayTimeSeconds(account.playTimeSeconds() + delta));
        });
    }

    public long totalSeconds(Account account) {
        Instant start = onlineSince.get(account.uuid());
        if (start == null) {
            return account.playTimeSeconds();
        }
        long delta = Math.max(0, Duration.between(start, Instant.now()).getSeconds());
        return account.playTimeSeconds() + delta;
    }

    public void forget(UUID uuid) {
        onlineSince.remove(uuid);
    }

    public void flush() {
        for (UUID uuid : onlineSince.keySet()) {
            stopAndSave(uuid);
        }
    }
}
