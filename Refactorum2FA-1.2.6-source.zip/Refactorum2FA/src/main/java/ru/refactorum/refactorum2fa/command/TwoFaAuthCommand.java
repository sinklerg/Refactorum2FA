package ru.refactorum.refactorum2fa.command;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.listener.ServerGateListener;
import ru.refactorum.refactorum2fa.model.Account;
import ru.refactorum.refactorum2fa.service.TwoFactorService;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class TwoFaAuthCommand implements SimpleCommand {
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;
    private final ServerGateListener serverGateListener;

    public TwoFaAuthCommand(ConfigManager configManager, TwoFactorService twoFactorService, ServerGateListener serverGateListener) {
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
        this.serverGateListener = serverGateListener;
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        if (!(source instanceof Player player)) {
            source.sendMessage(configManager.messages().minecraft("player-only"));
            return;
        }

        Optional<Account> optionalAccount = twoFactorService.account(player.getUniqueId());
        if (optionalAccount.isEmpty()) {
            player.sendMessage(configManager.messages().minecraft("not-linked-minecraft", Map.of(
                    "bot", configManager.config().telegram().botUsername()
            )));
            return;
        }

        if (twoFactorService.hasAuthorizedSession(player.getUniqueId())) {
            player.sendMessage(configManager.messages().minecraft("auth-session-valid", Map.of(
                    "server", configManager.config().network().targetServer()
            )));
            return;
        }

        if (twoFactorService.hasPendingAuth(player.getUniqueId())) {
            player.sendMessage(configManager.messages().minecraft("auth-already-pending", Map.of(
                    "server", configManager.config().network().targetServer(),
                    "bot", configManager.config().telegram().botUsername()
            )));
            return;
        }

        String sourceServer = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse(configManager.config().network().authServer());
        serverGateListener.startGate(player, optionalAccount.get(), sourceServer, configManager.config().network().targetServer());
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        return List.of();
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return true;
    }
}
