package ru.refactorum.refactorum2fa.paper;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import ru.refactorum.refactorum2fa.util.FreezeMessageCodec;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class Refactorum2FAHubPlugin extends JavaPlugin implements Listener, PluginMessageListener {
    private static final String DEFAULT_FREEZE_MESSAGE = "Сначала подтвердите вход через Telegram 2FA.";
    private static final long MESSAGE_COOLDOWN_MILLIS = 1200L;

    private final Map<UUID, String> frozenPlayers = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastMessageAt = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getMessenger().registerIncomingPluginChannel(this, FreezeMessageCodec.CHANNEL, this);
        getLogger().info("Paper/Purpur hub freeze helper enabled on channel " + FreezeMessageCodec.CHANNEL);
    }

    @Override
    public void onDisable() {
        frozenPlayers.clear();
        lastMessageAt.clear();
        Bukkit.getMessenger().unregisterIncomingPluginChannel(this, FreezeMessageCodec.CHANNEL, this);
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!FreezeMessageCodec.CHANNEL.equals(channel)) {
            return;
        }

        FreezeMessageCodec.decode(message).ifPresent(decoded -> Bukkit.getScheduler().runTask(this, () -> {
            Player target = Bukkit.getPlayer(decoded.uuid());
            if (decoded.freeze()) {
                String freezeMessage = decoded.message() == null || decoded.message().isBlank()
                        ? DEFAULT_FREEZE_MESSAGE
                        : decoded.message();
                frozenPlayers.put(decoded.uuid(), freezeMessage);
                if (target != null && target.isOnline()) {
                    target.sendMessage(freezeMessage);
                }
                getLogger().fine("Frozen pending 2FA player " + decoded.uuid());
                return;
            }

            if (decoded.unfreeze()) {
                frozenPlayers.remove(decoded.uuid());
                lastMessageAt.remove(decoded.uuid());
                getLogger().fine("Unfrozen 2FA player " + decoded.uuid());
            }
        }));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }

        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onMove(PlayerMoveEvent event) {
        if (!isFrozen(event.getPlayer()) || !changedPosition(event.getFrom(), event.getTo())) {
            return;
        }

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }
        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }

        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteractAtEntity(PlayerInteractAtEntityEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }

        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player) || !isFrozen(player)) {
            return;
        }

        event.setCancelled(true);
        warn(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !isFrozen(player)) {
            return;
        }

        event.setCancelled(true);
        warn(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !isFrozen(player)) {
            return;
        }

        event.setCancelled(true);
        warn(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onDrop(PlayerDropItemEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }

        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        if (!isFrozen(event.getPlayer())) {
            return;
        }

        event.setCancelled(true);
        warn(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        frozenPlayers.remove(uuid);
        lastMessageAt.remove(uuid);
    }

    private boolean isFrozen(Player player) {
        return frozenPlayers.containsKey(player.getUniqueId());
    }

    private void warn(Player player) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        long last = lastMessageAt.getOrDefault(uuid, 0L);
        if (now - last < MESSAGE_COOLDOWN_MILLIS) {
            return;
        }
        lastMessageAt.put(uuid, now);
        player.sendMessage(frozenPlayers.getOrDefault(uuid, DEFAULT_FREEZE_MESSAGE));
    }

    private boolean changedPosition(Location from, Location to) {
        if (to == null) {
            return false;
        }
        return from.getBlockX() != to.getBlockX()
                || from.getBlockY() != to.getBlockY()
                || from.getBlockZ() != to.getBlockZ()
                || Double.compare(from.getX(), to.getX()) != 0
                || Double.compare(from.getY(), to.getY()) != 0
                || Double.compare(from.getZ(), to.getZ()) != 0;
    }
}
