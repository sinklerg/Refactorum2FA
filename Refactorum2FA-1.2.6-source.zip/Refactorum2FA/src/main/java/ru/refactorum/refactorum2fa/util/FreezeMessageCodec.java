package ru.refactorum.refactorum2fa.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;

public final class FreezeMessageCodec {
    public static final String CHANNEL = "refactorum2fa:freeze";
    public static final String ACTION_FREEZE = "freeze";
    public static final String ACTION_UNFREEZE = "unfreeze";

    private FreezeMessageCodec() {
    }

    public static byte[] encode(String action, UUID uuid, String message) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream output = new DataOutputStream(bytes)) {
                output.writeUTF(action == null ? "" : action);
                output.writeUTF(uuid == null ? "" : uuid.toString());
                output.writeUTF(message == null ? "" : message);
            }
            return bytes.toByteArray();
        } catch (IOException exception) {
            return fallback(action, uuid, message);
        }
    }

    public static Optional<FreezeMessage> decode(byte[] payload) {
        if (payload == null || payload.length == 0) {
            return Optional.empty();
        }

        Optional<FreezeMessage> dataStreamMessage = decodeDataStream(payload);
        if (dataStreamMessage.isPresent()) {
            return dataStreamMessage;
        }
        return decodeFallback(payload);
    }

    private static Optional<FreezeMessage> decodeDataStream(byte[] payload) {
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(payload))) {
            String action = input.readUTF();
            UUID uuid = UUID.fromString(input.readUTF());
            String message = input.readUTF();
            return Optional.of(new FreezeMessage(action, uuid, message));
        } catch (IOException | IllegalArgumentException exception) {
            return Optional.empty();
        }
    }

    private static Optional<FreezeMessage> decodeFallback(byte[] payload) {
        String raw = new String(payload, StandardCharsets.UTF_8);
        String[] parts = raw.split("\\n", 3);
        if (parts.length < 2) {
            return Optional.empty();
        }
        try {
            return Optional.of(new FreezeMessage(
                    parts[0],
                    UUID.fromString(parts[1]),
                    parts.length >= 3 ? parts[2] : ""
            ));
        } catch (IllegalArgumentException exception) {
            return Optional.empty();
        }
    }

    private static byte[] fallback(String action, UUID uuid, String message) {
        return ((action == null ? "" : action)
                + "\n"
                + (uuid == null ? "" : uuid)
                + "\n"
                + (message == null ? "" : message)).getBytes(StandardCharsets.UTF_8);
    }

    public record FreezeMessage(String action, UUID uuid, String message) {
        public boolean freeze() {
            return ACTION_FREEZE.equalsIgnoreCase(action);
        }

        public boolean unfreeze() {
            return ACTION_UNFREEZE.equalsIgnoreCase(action);
        }
    }
}
