package ru.refactorum.refactorum2fa.config;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.util.HashMap;
import java.util.Map;

public final class Messages {
    private final YamlDocument document;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private String prefix = "";

    public Messages(YamlDocument document) {
        this.document = document;
        reloadPrefix();
    }

    public void reloadPrefix() {
        this.prefix = document.getString("prefix", "");
    }

    public Component minecraft(String key, Map<String, String> placeholders) {
        return miniMessage.deserialize(applyPlaceholders(document.getString("minecraft." + key, key), placeholders));
    }

    public Component minecraft(String key) {
        return minecraft(key, Map.of());
    }

    public String telegram(String key, Map<String, String> placeholders) {
        return stripMiniMessage(applyPlaceholders(document.getString("telegram." + key, key), placeholders));
    }

    public String telegram(String key) {
        return telegram(key, Map.of());
    }

    public String applyPlaceholders(String source, Map<String, String> placeholders) {
        Map<String, String> values = new HashMap<>(placeholders);
        values.putIfAbsent("prefix", prefix);
        String result = source;
        for (Map.Entry<String, String> entry : values.entrySet()) {
            result = result.replace("{" + entry.getKey() + "}", entry.getValue() == null ? "" : entry.getValue());
        }
        return result;
    }

    private String stripMiniMessage(String value) {
        return value
                .replace("<red>", "")
                .replace("</red>", "")
                .replace("<green>", "")
                .replace("</green>", "")
                .replace("<yellow>", "")
                .replace("</yellow>", "")
                .replace("<white>", "")
                .replace("</white>", "")
                .replace("<gray>", "")
                .replace("</gray>", "")
                .replace("<dark_gray>", "")
                .replace("</dark_gray>", "")
                .replace("<aqua>", "")
                .replace("</aqua>", "");
    }
}
