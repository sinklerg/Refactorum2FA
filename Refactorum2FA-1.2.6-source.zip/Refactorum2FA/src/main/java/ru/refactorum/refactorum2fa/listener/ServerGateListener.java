package ru.refactorum.refactorum2fa.listener;

import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import org.slf4j.Logger;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.config.PluginConfig;
import ru.refactorum.refactorum2fa.integration.AjQueueIntegration;
import ru.refactorum.refactorum2fa.model.Account;
import ru.refactorum.refactorum2fa.model.AuthDecision;
import ru.refactorum.refactorum2fa.service.TwoFactorService;

import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class ServerGateListener {
    private final Object plugin;
    private final ProxyServer server;
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;
    private final AjQueueIntegration ajQueueIntegration;
    private final Logger logger;

    public ServerGateListener(Object plugin,
                              ProxyServer server,
                              ConfigManager configManager,
                              TwoFactorService twoFactorService,
                              AjQueueIntegration ajQueueIntegration,
                              Logger logger) {
        this.plugin = plugin;
        this.server = server;
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
        this.ajQueueIntegration = ajQueueIntegration;
        this.logger = logger;
    }

    @Subscribe(priority = 100)
    public void onServerPreConnect(ServerPreConnectEvent event) {
        Player player = event.getPlayer();
        String targetServer = event.getOriginalServer().getServerInfo().getName();
        Optional<String> previousServer = Optional.ofNullable(event.getPreviousServer())
                .map(RegisteredServer::getServerInfo)
                .map(info -> info.getName());

        PluginConfig.Network network = configManager.config().network();
        if (!network.isProtectedServer(targetServer)) {
            return;
        }

        Optional<Account> optionalAccount = twoFactorService.account(player.getUniqueId());
        if (optionalAccount.isEmpty()) {
            return;
        }

        Account account = optionalAccount.get();
        if (account.blocked()) {
            event.setResult(ServerPreConnectEvent.ServerResult.denied());
            player.disconnect(configManager.messages().minecraft("login-denied-blocked"));
            return;
        }

        if (twoFactorService.hasAuthorizedSession(player.getUniqueId())) {
            return;
        }

        if (configManager.config().auth().allowPermissionBypass()
                && player.hasPermission(configManager.config().permissions().bypass())) {
            twoFactorService.authorizeSession(player.getUniqueId());
            twoFactorService.markSuccessfulLogin(account, player.getUsername(), address(player), targetServer);
            return;
        }

        event.setResult(ServerPreConnectEvent.ServerResult.denied());
        ajQueueIntegration.removePlayerQueues(player);

        if (twoFactorService.hasPendingAuth(player.getUniqueId())) {
            twoFactorService.freezePlayer(player);
            player.sendMessage(configManager.messages().minecraft("auth-already-pending", Map.of(
                    "server", targetServer,
                    "bot", configManager.config().telegram().botUsername()
            )));
            return;
        }

        player.sendMessage(configManager.messages().minecraft("login-required-before-2fa", Map.of(
                "auth_server", network.authServer(),
                "target_server", targetServer
        )));
    }

    @Subscribe(priority = 100)
    public void onCommandExecute(CommandExecuteEvent event) {
        if (!(event.getCommandSource() instanceof Player player)) {
            return;
        }

        if (shouldBlockQueueCommandUntilTwoFactor(player, event.getCommand())) {
            ajQueueIntegration.removePlayerQueues(player);
            if (twoFactorService.hasPendingAuth(player.getUniqueId())) {
                twoFactorService.freezePlayer(player);
            }
            event.setResult(CommandExecuteEvent.CommandResult.denied());
            player.sendMessage(configManager.messages().minecraft("queue-command-blocked-pending"));
            return;
        }

        if (configManager.config().auth().blockCommandsWhilePending()
                && twoFactorService.hasPendingAuth(player.getUniqueId())) {
            if (!configManager.config().auth().blockAllCommandsWhilePending()
                    && configManager.config().auth().isCommandAllowedWhilePending(event.getCommand())) {
                return;
            }
            event.setResult(CommandExecuteEvent.CommandResult.denied());
            player.sendMessage(configManager.messages().minecraft("command-blocked-pending"));
            return;
        }

        if (shouldStartTwoFactorAfterLoginCommand(player, event.getCommand())) {
            scheduleTwoFactorAfterLoginCommand(player);
        }
    }

    public void startGate(Player player, Account account, String sourceServer, String targetServer) {
        UUID uuid = player.getUniqueId();
        if (twoFactorService.hasPendingAuth(uuid)) {
            twoFactorService.freezePlayer(player);
            player.sendMessage(configManager.messages().minecraft("auth-already-pending", Map.of(
                    "server", targetServer,
                    "bot", configManager.config().telegram().botUsername()
            )));
            return;
        }

        if (account.blocked()) {
            player.disconnect(configManager.messages().minecraft("login-denied-blocked"));
            return;
        }

        if (configManager.config().auth().allowPermissionBypass()
                && player.hasPermission(configManager.config().permissions().bypass())) {
            twoFactorService.authorizeSession(uuid);
            twoFactorService.markSuccessfulLogin(account, player.getUsername(), address(player), targetServer);
            player.sendMessage(configManager.messages().minecraft("auth-session-valid", Map.of("server", targetServer)));
            return;
        }

        ajQueueIntegration.removePlayerQueues(player);
        twoFactorService.freezePlayer(player);
        player.sendMessage(configManager.messages().minecraft("auth-request-sent", Map.of(
                "server", targetServer,
                "bot", configManager.config().telegram().botUsername()
        )));

        twoFactorService.requestLogin(account, player.getUsername(), address(player), sourceServer, targetServer)
                .whenComplete((decision, throwable) -> server.getScheduler().buildTask(plugin, () -> {
                    AuthDecision finalDecision = throwable == null && decision != null ? decision : AuthDecision.ERROR;
                    applyDecision(player, account, targetServer, finalDecision);
                }).schedule());
    }

    private boolean shouldBlockQueueCommandUntilTwoFactor(Player player, String commandLine) {
        PluginConfig.Auth auth = configManager.config().auth();
        UUID uuid = player.getUniqueId();
        if (!auth.blockQueueCommandsUntil2fa()) {
            return false;
        }
        if (!auth.isQueueCommand(commandLine) && !isProtectedServerShortcut(commandLine)) {
            return false;
        }
        if (twoFactorService.hasAuthorizedSession(uuid)) {
            return false;
        }
        return twoFactorService.account(uuid).isPresent();
    }

    private boolean isProtectedServerShortcut(String commandLine) {
        String label = PluginConfig.Auth.commandLabel(commandLine);
        if (label.isBlank()) {
            return false;
        }
        PluginConfig.Network network = configManager.config().network();
        if (network.isProtectedServer(label)) {
            return true;
        }
        return network.targetServer() != null && network.targetServer().equalsIgnoreCase(label);
    }

    private boolean shouldStartTwoFactorAfterLoginCommand(Player player, String commandLine) {
        if (!configManager.config().auth().startTwoFactorAfterLoginCommand()) {
            return false;
        }
        if (!configManager.config().auth().isLoginCommand(commandLine)) {
            return false;
        }

        String currentServer = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse("");
        if (!configManager.config().network().isAuthServer(currentServer)) {
            return false;
        }

        Optional<Account> optionalAccount = twoFactorService.account(player.getUniqueId());
        if (optionalAccount.isEmpty()) {
            return false;
        }
        if (twoFactorService.hasAuthorizedSession(player.getUniqueId()) || twoFactorService.hasPendingAuth(player.getUniqueId())) {
            return false;
        }
        return true;
    }

    private void scheduleTwoFactorAfterLoginCommand(Player player) {
        UUID uuid = player.getUniqueId();
        long delayMillis = Math.max(0L, configManager.config().auth().loginCommandDelayMillis());
        server.getScheduler().buildTask(plugin, () -> server.getPlayer(uuid).ifPresent(online -> {
            String currentServer = online.getCurrentServer()
                    .map(connection -> connection.getServerInfo().getName())
                    .orElse("");
            if (!configManager.config().network().isAuthServer(currentServer)) {
                return;
            }
            if (twoFactorService.hasAuthorizedSession(uuid) || twoFactorService.hasPendingAuth(uuid)) {
                return;
            }
            twoFactorService.account(uuid).ifPresent(account -> startGate(
                    online,
                    account,
                    currentServer,
                    configManager.config().network().targetServer()
            ));
        })).delay(Duration.ofMillis(delayMillis)).schedule();
    }

    private void applyDecision(Player player, Account account, String targetServer, AuthDecision decision) {
        if (server.getPlayer(player.getUniqueId()).isEmpty()) {
            return;
        }

        switch (decision) {
            case APPROVED -> {
                twoFactorService.unfreezePlayer(player);
                twoFactorService.authorizeSession(player.getUniqueId());
                twoFactorService.markSuccessfulLogin(account, player.getUsername(), address(player), targetServer);
                player.sendMessage(configManager.messages().minecraft("auth-approved-connect", Map.of("server", targetServer)));
            }
            case DENIED -> player.disconnect(configManager.messages().minecraft("login-denied-rejected"));
            case TIMEOUT -> player.disconnect(configManager.messages().minecraft("login-denied-timeout"));
            case ERROR -> {
                if (configManager.config().auth().failClosed()) {
                    player.disconnect(configManager.messages().minecraft("login-denied-error"));
                } else {
                    twoFactorService.unfreezePlayer(player);
                    twoFactorService.authorizeSession(player.getUniqueId());
                    twoFactorService.markSuccessfulLogin(account, player.getUsername(), address(player), targetServer);
                    player.sendMessage(configManager.messages().minecraft("auth-approved-connect", Map.of("server", targetServer)));
                }
            }
        }
    }

    private String address(Player player) {
        InetSocketAddress remote = player.getRemoteAddress();
        if (remote == null || remote.getAddress() == null) {
            return "unknown";
        }
        return remote.getAddress().getHostAddress();
    }
}
