package ru.refactorum.refactorum2fa.listener;

import com.velocitypowered.api.event.ResultedEvent;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.player.ServerPostConnectEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import ru.refactorum.refactorum2fa.config.ConfigManager;
import ru.refactorum.refactorum2fa.model.Account;
import ru.refactorum.refactorum2fa.service.TwoFactorService;

import java.time.Duration;

public final class PlayerActivityListener {
    private final Object plugin;
    private final ProxyServer server;
    private final ConfigManager configManager;
    private final TwoFactorService twoFactorService;

    public PlayerActivityListener(Object plugin, ProxyServer server, ConfigManager configManager, TwoFactorService twoFactorService) {
        this.plugin = plugin;
        this.server = server;
        this.configManager = configManager;
        this.twoFactorService = twoFactorService;
    }

    @Subscribe(priority = 100)
    public void onLogin(LoginEvent event) {
        twoFactorService.account(event.getPlayer().getUniqueId())
                .filter(Account::blocked)
                .ifPresent(account -> event.setResult(ResultedEvent.ComponentResult.denied(
                        configManager.messages().minecraft("login-denied-blocked")
                )));
    }

    @Subscribe
    public void onPostLogin(PostLoginEvent event) {
        Player player = event.getPlayer();
        twoFactorService.account(player.getUniqueId()).ifPresent(account -> {
            if (account.blocked()) {
                player.disconnect(configManager.messages().minecraft("login-denied-blocked"));
                return;
            }
            twoFactorService.playtimeTracker().start(player.getUniqueId());
        });
    }

    @Subscribe
    public void onServerPostConnect(ServerPostConnectEvent event) {
        Player player = event.getPlayer();
        String currentServer = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse("");

        if (twoFactorService.hasPendingAuth(player.getUniqueId())) {
            twoFactorService.freezePlayer(player);
            return;
        }

        if (!configManager.config().joinSuggestion().enabled()) {
            return;
        }
        if (!configManager.config().joinSuggestion().appliesTo(currentServer)) {
            return;
        }
        if (configManager.config().joinSuggestion().showOnlyUnlinked() && twoFactorService.account(player.getUniqueId()).isPresent()) {
            return;
        }

        Duration delay = Duration.ofSeconds(Math.max(0, configManager.config().joinSuggestion().delaySeconds()));
        server.getScheduler().buildTask(plugin, () -> server.getPlayer(player.getUniqueId()).ifPresent(online -> {
            String onlineServer = online.getCurrentServer()
                    .map(connection -> connection.getServerInfo().getName())
                    .orElse("");
            if (!configManager.config().joinSuggestion().appliesTo(onlineServer)) {
                return;
            }
            if (configManager.config().joinSuggestion().showOnlyUnlinked() && twoFactorService.account(online.getUniqueId()).isPresent()) {
                return;
            }
            online.sendMessage(configManager.messages().minecraft("join-suggestion"));
        })).delay(delay).schedule();
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        twoFactorService.playtimeTracker().stopAndSave(event.getPlayer().getUniqueId());
        twoFactorService.clearSession(event.getPlayer().getUniqueId());
    }
}
