package ru.refactorum.refactorum2fa.util;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class FormatUtil {
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")
            .withZone(ZoneId.systemDefault());

    private FormatUtil() {
    }

    public static String instant(Instant instant, String neverText) {
        return instant == null ? neverText : DATE_TIME.format(instant);
    }

    public static String duration(long seconds, String daysTemplate, String hoursTemplate, String minutesTemplate) {
        Duration duration = Duration.ofSeconds(Math.max(0, seconds));
        long days = duration.toDays();
        long hours = duration.toHoursPart();
        long minutes = duration.toMinutesPart();

        if (days > 0) {
            return applyDuration(daysTemplate, days, hours, minutes);
        }
        if (hours > 0) {
            return applyDuration(hoursTemplate, days, hours, minutes);
        }
        return applyDuration(minutesTemplate, days, hours, Math.max(0, duration.toMinutes()));
    }

    public static String yesNo(boolean value, String yesText, String noText) {
        return value ? yesText : noText;
    }

    public static String online(boolean value, String onlineText, String offlineText) {
        return value ? onlineText : offlineText;
    }

    private static String applyDuration(String template, long days, long hours, long minutes) {
        return template
                .replace("{days}", String.valueOf(days))
                .replace("{hours}", String.valueOf(hours))
                .replace("{minutes}", String.valueOf(minutes));
    }
}
